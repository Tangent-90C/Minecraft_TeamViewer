package fun.prof_chen.teamviewer.multipleplayeresp.ui;

import fun.prof_chen.teamviewer.multipleplayeresp.core.StandaloneMultiPlayerESP;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class PlayerESPWaypointShapeConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 waypointBeamWidthField;
    private class_342 waypointBeamHeightField;
    private class_342 tmBeamWidthField;
    private class_342 tmBeamHeightField;

    private static final int COMPONENT_WIDTH = 170;
    private static final int COMPONENT_HEIGHT = 20;
    private static final int COMPONENT_SPACING = 30;
    private static final int LABEL_SPACING = 12;
    private static final int BUTTON_SPACING = 25;
    private static final int COLUMN_GAP = 6;
    private int startY;
    private int currentY;

    public PlayerESPWaypointShapeConfigScreen(class_437 parent) {
        super(class_2561.method_43471("screen.multipleplayeresp.waypoint_shape_config.title"));
        this.parent = parent;
    }

    private void calculateLayout() {
        int totalHeight = 0;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += BUTTON_SPACING;

        startY = (this.field_22790 - totalHeight) / 2;
        currentY = startY;
    }

    private int getNextY() {
        int result = currentY;
        currentY += COMPONENT_SPACING;
        return result;
    }

    private int getNextButtonY() {
        int result = currentY;
        currentY += BUTTON_SPACING;
        return result;
    }

    private int getLeftColumnX() {
        int totalWidth = COMPONENT_WIDTH * 2 + COLUMN_GAP;
        return (this.field_22789 - totalWidth) / 2;
    }

    private int getRightColumnX() {
        return getLeftColumnX() + COMPONENT_WIDTH + COLUMN_GAP;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        calculateLayout();
        currentY += COMPONENT_SPACING;

        int leftX = getLeftColumnX();
        int rightX = getRightColumnX();

        int firstRowY = getNextY();
        this.waypointBeamWidthField = new class_342(
            this.field_22793,
            leftX,
            firstRowY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.waypoint_beacon_beam_width")
        );
        this.waypointBeamWidthField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getWaypointBeaconBeamWidth()));
        this.waypointBeamWidthField.method_1880(10);
        this.waypointBeamWidthField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.waypoint_beacon_beam_width_hint"));
        this.method_37063(this.waypointBeamWidthField);

        this.method_37063(
            new class_7842(leftX, firstRowY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.waypoint_beacon_beam_width"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        this.waypointBeamHeightField = new class_342(
            this.field_22793,
            rightX,
            firstRowY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.waypoint_beacon_beam_height")
        );
        this.waypointBeamHeightField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getWaypointBeaconBeamHeight()));
        this.waypointBeamHeightField.method_1880(10);
        this.waypointBeamHeightField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.waypoint_beacon_beam_height_hint"));
        this.method_37063(this.waypointBeamHeightField);

        this.method_37063(
            new class_7842(rightX, firstRowY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.waypoint_beacon_beam_height"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        int secondRowY = getNextY();
        this.tmBeamWidthField = new class_342(
            this.field_22793,
            leftX,
            secondRowY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.tampermonkey_beam_width")
        );
        this.tmBeamWidthField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getTampermonkeyBeamWidth()));
        this.tmBeamWidthField.method_1880(10);
        this.tmBeamWidthField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.tampermonkey_beam_width_hint"));
        this.method_37063(this.tmBeamWidthField);

        this.method_37063(
            new class_7842(leftX, secondRowY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.tampermonkey_beam_width"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        this.tmBeamHeightField = new class_342(
            this.field_22793,
            rightX,
            secondRowY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.tampermonkey_beam_height")
        );
        this.tmBeamHeightField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getTampermonkeyBeamHeight()));
        this.tmBeamHeightField.method_1880(10);
        this.tmBeamHeightField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.tampermonkey_beam_height_hint"));
        this.method_37063(this.tmBeamHeightField);

        this.method_37063(
            new class_7842(rightX, secondRowY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.tampermonkey_beam_height"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        int backButtonY = getNextButtonY();
        this.method_37063(class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.back"),
            button -> method_25419()
        ).method_46434(leftX, backButtonY, COMPONENT_WIDTH * 2 + COLUMN_GAP, COMPONENT_HEIGHT).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(
            this.field_22793,
            this.field_22785,
            this.field_22789 / 2,
            startY - 30,
            0xFFFFFF
        );

        if (this.waypointBeamWidthField != null && this.waypointBeamWidthField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.waypoint_beacon_beam_width.tooltip", mouseX, mouseY);
            return;
        }
        if (this.waypointBeamHeightField != null && this.waypointBeamHeightField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.waypoint_beacon_beam_height.tooltip", mouseX, mouseY);
            return;
        }
        if (this.tmBeamWidthField != null && this.tmBeamWidthField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.tampermonkey_beam_width.tooltip", mouseX, mouseY);
            return;
        }
        if (this.tmBeamHeightField != null && this.tmBeamHeightField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.tampermonkey_beam_height.tooltip", mouseX, mouseY);
        }
    }

    private void drawTooltip(class_332 context, String key, int mouseX, int mouseY) {
        String text = class_2561.method_43471(key).getString();
        if (text == null || text.isBlank()) {
            return;
        }
        List<class_2561> lines = splitTooltipLines(text, 42);
        context.method_51434(this.field_22793, lines, mouseX, mouseY);
    }

    private List<class_2561> splitTooltipLines(String input, int maxChars) {
        List<class_2561> lines = new ArrayList<>();
        if (input == null || input.isBlank()) {
            return lines;
        }
        String[] words = input.trim().split("\\s+");
        StringBuilder currentLine = new StringBuilder();
        for (String word : words) {
            if (currentLine.length() == 0) {
                currentLine.append(word);
                continue;
            }
            if (currentLine.length() + 1 + word.length() <= maxChars) {
                currentLine.append(' ').append(word);
            } else {
                lines.add(class_2561.method_30163(currentLine.toString()));
                currentLine.setLength(0);
                currentLine.append(word);
            }
        }
        if (currentLine.length() > 0) {
            lines.add(class_2561.method_30163(currentLine.toString()));
        }
        return lines;
    }

    @Override
    public void method_25419() {
        applyFieldValues();
        class_310.method_1551().method_1507(this.parent);
    }

    private void applyFieldValues() {
        try {
            String waypointBeamWidthStr = this.waypointBeamWidthField.method_1882().trim();
            if (!waypointBeamWidthStr.isEmpty()) {
                double waypointBeamWidth = Double.parseDouble(waypointBeamWidthStr);
                StandaloneMultiPlayerESP.getConfig().setWaypointBeaconBeamWidth(waypointBeamWidth);
            }

            String waypointBeamHeightStr = this.waypointBeamHeightField.method_1882().trim();
            if (!waypointBeamHeightStr.isEmpty()) {
                double waypointBeamHeight = Double.parseDouble(waypointBeamHeightStr);
                StandaloneMultiPlayerESP.getConfig().setWaypointBeaconBeamHeight(waypointBeamHeight);
            }

            String tmBeamWidthStr = this.tmBeamWidthField.method_1882().trim();
            if (!tmBeamWidthStr.isEmpty()) {
                double tmBeamWidth = Double.parseDouble(tmBeamWidthStr);
                StandaloneMultiPlayerESP.getConfig().setTampermonkeyBeamWidth(tmBeamWidth);
            }

            String tmBeamHeightStr = this.tmBeamHeightField.method_1882().trim();
            if (!tmBeamHeightStr.isEmpty()) {
                double tmBeamHeight = Double.parseDouble(tmBeamHeightStr);
                StandaloneMultiPlayerESP.getConfig().setTampermonkeyBeamHeight(tmBeamHeight);
            }
        } catch (NumberFormatException e) {
        }
    }
}

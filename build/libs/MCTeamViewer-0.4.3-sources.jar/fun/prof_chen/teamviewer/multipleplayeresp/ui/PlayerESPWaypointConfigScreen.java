package fun.prof_chen.teamviewer.multipleplayeresp.ui;

import fun.prof_chen.teamviewer.multipleplayeresp.config.Config;
import fun.prof_chen.teamviewer.multipleplayeresp.core.StandaloneMultiPlayerESP;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class PlayerESPWaypointConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 waypointTimeoutField;
    private class_342 longTermWaypointTimeoutField;
    private class_342 quickMarkMaxCountField;
    private class_4185 waypointUiStyleButton;
    private class_4185 showSharedWaypointsButton;
    private class_4185 showOwnSharedWaypointsOnMinimapButton;
    private class_4185 middleDoubleClickMarkButton;
    private class_4185 middleClickCancelWaypointButton;
    private class_4185 autoCancelWaypointOnEntityDeathButton;
    private class_4185 enableLongTermWaypointButton;
    private class_4185 waypointShapeSettingsButton;

    private static final int COMPONENT_WIDTH = 170;
    private static final int COMPONENT_HEIGHT = 20;
    private static final int COMPONENT_SPACING = 30;
    private static final int LABEL_SPACING = 12;
    private static final int BUTTON_SPACING = 25;
    private static final int COLUMN_GAP = 6;
    private int startY;
    private int currentY;

    public PlayerESPWaypointConfigScreen(class_437 parent) {
        super(class_2561.method_43471("screen.multipleplayeresp.waypoint_config.title"));
        this.parent = parent;
    }

    private void calculateLayout() {
        int totalHeight = 0;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;

        startY = (this.field_22790 - totalHeight) / 2;
        currentY = startY;
    }

    private int getNextY() {
        int result = currentY;
        currentY += COMPONENT_SPACING;
        return result;
    }

    private int getNextButtonY() {
        int result = currentY;
        currentY += BUTTON_SPACING;
        return result;
    }

    private int getLeftColumnX() {
        int totalWidth = COMPONENT_WIDTH * 2 + COLUMN_GAP;
        return (this.field_22789 - totalWidth) / 2;
    }

    private int getRightColumnX() {
        return getLeftColumnX() + COMPONENT_WIDTH + COLUMN_GAP;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        calculateLayout();
        currentY += COMPONENT_SPACING;

        int leftX = getLeftColumnX();
        int rightX = getRightColumnX();

        int firstFieldY = getNextY();
        this.waypointTimeoutField = new class_342(
            this.field_22793,
            leftX,
            firstFieldY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.waypoint_timeout")
        );
        this.waypointTimeoutField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getWaypointTimeoutSeconds()));
        this.waypointTimeoutField.method_1880(10);
        this.waypointTimeoutField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.waypoint_timeout_hint"));
        this.method_37063(this.waypointTimeoutField);

        this.method_37063(
            new class_7842(leftX, firstFieldY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.waypoint_timeout"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        this.longTermWaypointTimeoutField = new class_342(
            this.field_22793,
            rightX,
            firstFieldY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.long_term_waypoint_timeout")
        );
        this.longTermWaypointTimeoutField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getLongTermWaypointTimeoutSeconds()));
        this.longTermWaypointTimeoutField.method_1880(10);
        this.longTermWaypointTimeoutField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.long_term_waypoint_timeout_hint"));
        this.method_37063(this.longTermWaypointTimeoutField);

        this.method_37063(
            new class_7842(rightX, firstFieldY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.long_term_waypoint_timeout"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        int secondFieldY = getNextY();
        this.quickMarkMaxCountField = new class_342(
            this.field_22793,
            leftX,
            secondFieldY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.quick_mark_max_count")
        );
        this.quickMarkMaxCountField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getMaxQuickMarkCount()));
        this.quickMarkMaxCountField.method_1880(10);
        this.quickMarkMaxCountField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.quick_mark_max_count_hint"));
        this.method_37063(this.quickMarkMaxCountField);

        this.method_37063(
            new class_7842(leftX, secondFieldY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.quick_mark_max_count"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        this.waypointUiStyleButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.waypoint_ui_style"),
            button -> toggleWaypointUiStyle()
        ).method_46434(rightX, secondFieldY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.waypointUiStyleButton);

        int sharedWaypointY = getNextButtonY();
        this.showSharedWaypointsButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.show_shared_waypoints"),
            button -> toggleShowSharedWaypoints()
        ).method_46434(leftX, sharedWaypointY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.showSharedWaypointsButton);

        this.showOwnSharedWaypointsOnMinimapButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.show_own_shared_waypoints_on_minimap"),
            button -> toggleShowOwnSharedWaypointsOnMinimap()
        ).method_46434(rightX, sharedWaypointY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.showOwnSharedWaypointsOnMinimapButton);

        int middleClickMarkY = getNextButtonY();
        this.middleDoubleClickMarkButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.middle_double_click_mark"),
            button -> toggleMiddleDoubleClickMark()
        ).method_46434(leftX, middleClickMarkY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.middleDoubleClickMarkButton);

        this.middleClickCancelWaypointButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.middle_click_cancel_waypoint"),
            button -> toggleMiddleClickCancelWaypoint()
        ).method_46434(rightX, middleClickMarkY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.middleClickCancelWaypointButton);

        int longTermWaypointY = getNextButtonY();
        this.enableLongTermWaypointButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.enable_long_term_waypoint"),
            button -> toggleEnableLongTermWaypoint()
        ).method_46434(leftX, longTermWaypointY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.enableLongTermWaypointButton);

        this.autoCancelWaypointOnEntityDeathButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.auto_cancel_waypoint_on_entity_death"),
            button -> toggleAutoCancelWaypointOnEntityDeath()
        ).method_46434(rightX, longTermWaypointY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.autoCancelWaypointOnEntityDeathButton);

        int shapeSettingsY = getNextButtonY();
        this.waypointShapeSettingsButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.waypoint_shape_settings"),
            button -> openWaypointShapeConfig()
        ).method_46434(leftX, shapeSettingsY, COMPONENT_WIDTH * 2 + COLUMN_GAP, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.waypointShapeSettingsButton);

        int backButtonY = getNextButtonY();
        this.method_37063(class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.back"),
            button -> method_25419()
        ).method_46434(leftX, backButtonY, COMPONENT_WIDTH * 2 + COLUMN_GAP, COMPONENT_HEIGHT).method_46431());

        updateShowSharedWaypointsButton();
        updateShowOwnSharedWaypointsOnMinimapButton();
        updateMiddleDoubleClickMarkButton();
        updateMiddleClickCancelWaypointButton();
        updateAutoCancelWaypointOnEntityDeathButton();
        updateEnableLongTermWaypointButton();
        updateWaypointUiStyleButton();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(
            this.field_22793,
            this.field_22785,
            this.field_22789 / 2,
            startY - 30,
            0xFFFFFF
        );

        if (this.waypointTimeoutField != null && this.waypointTimeoutField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.waypoint_timeout.tooltip", mouseX, mouseY);
            return;
        }
        if (this.longTermWaypointTimeoutField != null && this.longTermWaypointTimeoutField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.long_term_waypoint_timeout.tooltip", mouseX, mouseY);
            return;
        }
        if (this.quickMarkMaxCountField != null && this.quickMarkMaxCountField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.quick_mark_max_count.tooltip", mouseX, mouseY);
            return;
        }
        if (this.waypointUiStyleButton != null && this.waypointUiStyleButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.waypoint_ui_style.tooltip", mouseX, mouseY);
            return;
        }
        if (this.showSharedWaypointsButton != null && this.showSharedWaypointsButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.show_shared_waypoints.tooltip", mouseX, mouseY);
            return;
        }
        if (this.showOwnSharedWaypointsOnMinimapButton != null && this.showOwnSharedWaypointsOnMinimapButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.show_own_shared_waypoints_on_minimap.tooltip", mouseX, mouseY);
            return;
        }
        if (this.middleDoubleClickMarkButton != null && this.middleDoubleClickMarkButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.middle_double_click_mark.tooltip", mouseX, mouseY);
            return;
        }
        if (this.middleClickCancelWaypointButton != null && this.middleClickCancelWaypointButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.middle_click_cancel_waypoint.tooltip", mouseX, mouseY);
            return;
        }
        if (this.autoCancelWaypointOnEntityDeathButton != null && this.autoCancelWaypointOnEntityDeathButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.auto_cancel_waypoint_on_entity_death.tooltip", mouseX, mouseY);
            return;
        }
        if (this.enableLongTermWaypointButton != null && this.enableLongTermWaypointButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.enable_long_term_waypoint.tooltip", mouseX, mouseY);
            return;
        }
        if (this.waypointShapeSettingsButton != null && this.waypointShapeSettingsButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.waypoint_shape_settings.tooltip", mouseX, mouseY);
        }
    }

    private void drawTooltip(class_332 context, String key, int mouseX, int mouseY) {
        String text = class_2561.method_43471(key).getString();
        if (text == null || text.isBlank()) {
            return;
        }
        List<class_2561> lines = splitTooltipLines(text, 42);
        context.method_51434(this.field_22793, lines, mouseX, mouseY);
    }

    private List<class_2561> splitTooltipLines(String input, int maxChars) {
        List<class_2561> lines = new ArrayList<>();
        if (input == null || input.isBlank()) {
            return lines;
        }
        String[] words = input.trim().split("\\s+");
        StringBuilder currentLine = new StringBuilder();
        for (String word : words) {
            if (currentLine.length() == 0) {
                currentLine.append(word);
                continue;
            }
            if (currentLine.length() + 1 + word.length() <= maxChars) {
                currentLine.append(' ').append(word);
            } else {
                lines.add(class_2561.method_30163(currentLine.toString()));
                currentLine.setLength(0);
                currentLine.append(word);
            }
        }
        if (currentLine.length() > 0) {
            lines.add(class_2561.method_30163(currentLine.toString()));
        }
        return lines;
    }

    @Override
    public void method_25419() {
        applyFieldValues();
        class_310.method_1551().method_1507(this.parent);
    }

    private void toggleShowSharedWaypoints() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isShowSharedWaypoints();
        StandaloneMultiPlayerESP.getConfig().setShowSharedWaypoints(!currentStatus);
        updateShowSharedWaypointsButton();
    }

    private void updateShowSharedWaypointsButton() {
        if (this.showSharedWaypointsButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isShowSharedWaypoints();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.show_shared_waypoints").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.showSharedWaypointsButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void toggleShowOwnSharedWaypointsOnMinimap() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isShowOwnSharedWaypointsOnMinimap();
        StandaloneMultiPlayerESP.getConfig().setShowOwnSharedWaypointsOnMinimap(!currentStatus);
        updateShowOwnSharedWaypointsOnMinimapButton();
    }

    private void updateShowOwnSharedWaypointsOnMinimapButton() {
        if (this.showOwnSharedWaypointsOnMinimapButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isShowOwnSharedWaypointsOnMinimap();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.show_own_shared_waypoints_on_minimap").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.showOwnSharedWaypointsOnMinimapButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void toggleMiddleDoubleClickMark() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isEnableMiddleDoubleClickMark();
        StandaloneMultiPlayerESP.getConfig().setEnableMiddleDoubleClickMark(!currentStatus);
        updateMiddleDoubleClickMarkButton();
    }

    private void updateMiddleDoubleClickMarkButton() {
        if (this.middleDoubleClickMarkButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isEnableMiddleDoubleClickMark();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.middle_double_click_mark").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.middleDoubleClickMarkButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void toggleMiddleClickCancelWaypoint() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isEnableMiddleClickCancelWaypoint();
        StandaloneMultiPlayerESP.getConfig().setEnableMiddleClickCancelWaypoint(!currentStatus);
        updateMiddleClickCancelWaypointButton();
    }

    private void updateMiddleClickCancelWaypointButton() {
        if (this.middleClickCancelWaypointButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isEnableMiddleClickCancelWaypoint();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.middle_click_cancel_waypoint").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.middleClickCancelWaypointButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void toggleAutoCancelWaypointOnEntityDeath() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isAutoCancelWaypointOnEntityDeath();
        StandaloneMultiPlayerESP.getConfig().setAutoCancelWaypointOnEntityDeath(!currentStatus);
        updateAutoCancelWaypointOnEntityDeathButton();
    }

    private void updateAutoCancelWaypointOnEntityDeathButton() {
        if (this.autoCancelWaypointOnEntityDeathButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isAutoCancelWaypointOnEntityDeath();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.auto_cancel_waypoint_on_entity_death").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.autoCancelWaypointOnEntityDeathButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void toggleEnableLongTermWaypoint() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isEnableLongTermWaypoint();
        StandaloneMultiPlayerESP.getConfig().setEnableLongTermWaypoint(!currentStatus);
        updateEnableLongTermWaypointButton();
    }

    private void updateEnableLongTermWaypointButton() {
        if (this.enableLongTermWaypointButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isEnableLongTermWaypoint();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.enable_long_term_waypoint").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.enableLongTermWaypointButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void toggleWaypointUiStyle() {
        Config config = StandaloneMultiPlayerESP.getConfig();
        String current = config.getWaypointUiStyle();
        if (Config.WAYPOINT_UI_BEACON.equals(current)) {
            config.setWaypointUiStyle(Config.WAYPOINT_UI_RING);
        } else if (Config.WAYPOINT_UI_RING.equals(current)) {
            config.setWaypointUiStyle(Config.WAYPOINT_UI_PIN);
        } else {
            config.setWaypointUiStyle(Config.WAYPOINT_UI_BEACON);
        }
        updateWaypointUiStyleButton();
    }

    private void updateWaypointUiStyleButton() {
        if (this.waypointUiStyleButton != null) {
            String style = StandaloneMultiPlayerESP.getConfig().getWaypointUiStyle();
            String styleKey;
            if (Config.WAYPOINT_UI_RING.equals(style)) {
                styleKey = "screen.multipleplayeresp.config.waypoint_ui_style.ring";
            } else if (Config.WAYPOINT_UI_PIN.equals(style)) {
                styleKey = "screen.multipleplayeresp.config.waypoint_ui_style.pin";
            } else {
                styleKey = "screen.multipleplayeresp.config.waypoint_ui_style.beacon";
            }
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.waypoint_ui_style").getString()
                + ": "
                + class_2561.method_43471(styleKey).getString();
            this.waypointUiStyleButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void openWaypointShapeConfig() {
        class_310.method_1551().method_1507(new PlayerESPWaypointShapeConfigScreen(this));
    }

    private void applyFieldValues() {
        try {
            String waypointTimeoutStr = this.waypointTimeoutField.method_1882().trim();
            if (!waypointTimeoutStr.isEmpty()) {
                int waypointTimeout = Integer.parseInt(waypointTimeoutStr);
                StandaloneMultiPlayerESP.getConfig().setWaypointTimeoutSeconds(waypointTimeout);
            }

            String longTermWaypointTimeoutStr = this.longTermWaypointTimeoutField.method_1882().trim();
            if (!longTermWaypointTimeoutStr.isEmpty()) {
                int longTermWaypointTimeout = Integer.parseInt(longTermWaypointTimeoutStr);
                StandaloneMultiPlayerESP.getConfig().setLongTermWaypointTimeoutSeconds(longTermWaypointTimeout);
            }

            String quickMarkMaxCountStr = this.quickMarkMaxCountField.method_1882().trim();
            if (!quickMarkMaxCountStr.isEmpty()) {
                int quickMarkMaxCount = Integer.parseInt(quickMarkMaxCountStr);
                StandaloneMultiPlayerESP.getConfig().setMaxQuickMarkCount(quickMarkMaxCount);
            }
        } catch (NumberFormatException e) {
        }
    }

    @Override
    public void method_25393() {
        super.method_25393();
        updateShowSharedWaypointsButton();
        updateShowOwnSharedWaypointsOnMinimapButton();
        updateMiddleDoubleClickMarkButton();
        updateMiddleClickCancelWaypointButton();
        updateAutoCancelWaypointOnEntityDeathButton();
        updateEnableLongTermWaypointButton();
        updateWaypointUiStyleButton();
    }
}
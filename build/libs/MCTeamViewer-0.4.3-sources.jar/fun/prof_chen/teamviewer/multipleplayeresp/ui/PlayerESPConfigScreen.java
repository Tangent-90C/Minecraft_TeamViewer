package fun.prof_chen.teamviewer.multipleplayeresp.ui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;
import fun.prof_chen.teamviewer.multipleplayeresp.core.StandaloneMultiPlayerESP;
import fun.prof_chen.teamviewer.multipleplayeresp.network.PlayerESPNetworkManager;
import fun.prof_chen.teamviewer.multipleplayeresp.network.PlayerESPNetworkManager.ConnectionStatusListener;

public class PlayerESPConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 urlField;
    private class_342 roomCodeField;
    private class_4185 connectButton;
    private class_4185 displaySettingsButton;
    private class_4185 networkSettingsButton;
    private class_4185 disconnectButton;
    private class_4185 exitSaveButton;
    // 连接状态显示
    private class_7842 connectionStatusWidget;
    private class_7842 saveHintWidget;
    private int connectionStatusX;
    private int connectionStatusY;
    private String currentConnectionStatus = "Unknown";
    // 保存原始值，用于取消时恢复
    private String originalURL;
    private String originalRoomCode;
    
    // 自动布局相关变量
    private static final int COMPONENT_WIDTH = 200;
    private static final int COMPONENT_HEIGHT = 20;
    private static final int COMPONENT_SPACING = 30;
    private static final int LABEL_SPACING = 12;
    private static final int BUTTON_SPACING = 25;
    private static final int URL_MAX_LENGTH = 2048;
    private static final int ROOM_CODE_MAX_LENGTH = 64;
    private static final int SAVE_HINT_COLOR_HIGHLIGHT = 0xFFAA00;
    private int startY;
    private int currentY;
    
    public PlayerESPConfigScreen(class_437 parent) {
        super(class_2561.method_43471("screen.multipleplayeresp.config.title"));
        this.parent = parent;
        this.originalURL = PlayerESPNetworkManager.getServerURL();
        this.originalRoomCode = PlayerESPNetworkManager.getRoomCode();
        // 初始化连接状态
        updateConnectionStatus();
    }
    
    /**
     * 计算起始Y坐标，使所有组件居中显示
     */
    private void calculateLayout() {
        // 计算总高度需求
        int totalHeight = 0;
        totalHeight += COMPONENT_SPACING; // 标题间距
        totalHeight += COMPONENT_SPACING; // URL输入框组
        totalHeight += COMPONENT_SPACING; // 房间号输入框组
        totalHeight += BUTTON_SPACING;    // 显示设置/网络设置按钮行
        totalHeight += BUTTON_SPACING;    // 退出保存按钮行
        totalHeight += BUTTON_SPACING;    // 连接按钮
        totalHeight += COMPONENT_SPACING; // 连接状态显示
        totalHeight += COMPONENT_SPACING; // 保存提示
        
        // 计算起始Y坐标
        startY = (this.field_22790 - totalHeight) / 2;
        currentY = startY;
    }
    
    /**
     * 获取下一个组件的Y坐标
     */
    private int getNextY() {
        int result = currentY;
        currentY += COMPONENT_SPACING;
        return result;
    }
    
    /**
     * 获取按钮组的Y坐标（较大间距）
     */
    private int getNextButtonY() {
        int result = currentY;
        currentY += BUTTON_SPACING;
        return result;
    }
    
    /**
     * 获取组件的X坐标（居中）
     */
    private int getComponentX() {
        return (this.field_22789 - COMPONENT_WIDTH) / 2;
    }
    
    // 连接状态监听器实例
    private final ConnectionStatusListener connectionListener = connected -> class_310.method_1551().execute(() -> {
        updateConnectionStatus();
        updateConnectionStatusWidget();
    });
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        // 计算自动布局参数
        calculateLayout();
        
        // 跳过标题间距
        currentY += COMPONENT_SPACING;
        
        // 服务器URL输入框
        int componentX = getComponentX();
        int urlY = getNextY();
        this.urlField = new class_342(
            this.field_22793,
            componentX,
            urlY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.url")
        );
        this.urlField.method_1880(URL_MAX_LENGTH);
        this.urlField.method_1852(PlayerESPNetworkManager.getServerURL());
        this.urlField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.url_hint"));
        this.method_37063(this.urlField);
        
        // URL标签
        this.method_37063(
            new class_7842(componentX, urlY - LABEL_SPACING, COMPONENT_WIDTH, 12, 
                class_2561.method_43471("screen.multipleplayeresp.config.url"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        // 房间号输入框
        int roomCodeY = getNextY();
        this.roomCodeField = new class_342(
            this.field_22793,
            componentX,
            roomCodeY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.room_code")
        );
        this.roomCodeField.method_1880(ROOM_CODE_MAX_LENGTH);
        this.roomCodeField.method_1852(PlayerESPNetworkManager.getRoomCode());
        this.roomCodeField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.room_code_hint"));
        this.method_37063(this.roomCodeField);

        this.method_37063(
            new class_7842(componentX, roomCodeY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.room_code"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );
        
        // 显示设置/网络设置按钮（左右布局）
        int settingsY = getNextButtonY();
        int settingsButtonWidth = (COMPONENT_WIDTH - 2) / 2;
        this.displaySettingsButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.display_settings"),
            button -> openDisplaySettings()
        ).method_46434(componentX, settingsY, settingsButtonWidth, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.displaySettingsButton);

        this.networkSettingsButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.network_settings"),
            button -> openNetworkSettings()
        ).method_46434(componentX + settingsButtonWidth + 2, settingsY, settingsButtonWidth, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.networkSettingsButton);
        
        int exitSaveY = getNextButtonY();
        this.exitSaveButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.save_network_settings"),
            button -> saveAndClose()
        ).method_46434(componentX, exitSaveY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.exitSaveButton);
        
        // 连接按钮
        int connectY = getNextButtonY();
        int connectButtonWidth = (COMPONENT_WIDTH - 2) / 2;
        this.connectButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.connect"),
            button -> connectToServer()
        ).method_46434(componentX, connectY, connectButtonWidth, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.connectButton);

        this.disconnectButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.disconnect"),
            button -> disconnectFromServer()
        ).method_46434(componentX + connectButtonWidth + 2, connectY, connectButtonWidth, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.disconnectButton);
        
        // 更新连接按钮文本
        updateConnectButton();
        
        // 添加连接状态显示组件
        addConnectionStatusWidget();

        // 添加保存提示组件
        addSaveHintWidget();
        
        // 注册连接状态监听器
        StandaloneMultiPlayerESP.getNetworkManager().addConnectionStatusListener(connectionListener);
    }
    
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // 1.21.8: 每帧只能 blur 一次，由 super.render() 内部统一调用 renderBackground，此处不再重复调用
        super.method_25394(context, mouseX, mouseY, delta);
        
        // 绘制标题（在布局上方）
        context.method_27534(
            this.field_22793,
            this.field_22785,
            this.field_22789 / 2,
            startY - 30,
            0xFFFFFF
        );

        if ("Failed".equals(this.currentConnectionStatus) && isMouseOverConnectionStatus(mouseX, mouseY)) {
            String reason = StandaloneMultiPlayerESP.getNetworkManager().getLastConnectionError();
            if (reason == null || reason.isBlank()) {
                reason = class_2561.method_43471("screen.multipleplayeresp.config.unknown_error").getString();
            }
            context.method_51434(
                this.field_22793,
                splitTooltipLines(reason, 48),
                mouseX,
                mouseY
            );
        }
        
    }
    
    @Override
    public void method_25419() {
        // 移除连接状态监听器
        StandaloneMultiPlayerESP.getNetworkManager().removeConnectionStatusListener(connectionListener);
        
        // 仅恢复高危参数：服务器URL与房间号
        PlayerESPNetworkManager.setServerURL(this.originalURL);
        PlayerESPNetworkManager.setRoomCode(this.originalRoomCode);
        
        class_310.method_1551().method_1507(this.parent);
    }
    
    private void saveSettings() {
        // 保存设置
        try {
            String url = this.urlField.method_1882().trim();
            if (!url.isEmpty()) {
                PlayerESPNetworkManager.setServerURL(url);
            }
            String roomCode = this.roomCodeField.method_1882().trim();
            PlayerESPNetworkManager.setRoomCode(roomCode);
            
            // 显示/网络开关设置在二级页面中实时保存
            // 保存配置到文件
            StandaloneMultiPlayerESP.getConfig().save();

            // 刷新“已保存”基线，避免保存后被取消回滚
            this.originalURL = PlayerESPNetworkManager.getServerURL();
            this.originalRoomCode = PlayerESPNetworkManager.getRoomCode();
            updateSaveHintWidget();
            updateSaveButton();
        } catch (NumberFormatException e) {
            // 如果输入格式不正确，忽略错误并使用原始值
        }
    }
    
    private void saveAndClose() {
        // 保存设置
        saveSettings();
        
        class_310.method_1551().method_1507(this.parent);
    }
    
    private void connectToServer() {
        // 先保存设置（但不关闭屏幕）
        saveSettings();
        
        // 尝试连接到服务器
        if (StandaloneMultiPlayerESP.isEspEnabled()) {
            // 如果ESP已启用，重新连接
            StandaloneMultiPlayerESP.reconnectToServer();
        } else {
            // 如果ESP未启用，启用它
            StandaloneMultiPlayerESP.setEspEnabled(true);
            StandaloneMultiPlayerESP.reconnectToServer();
        }
    }
    
    private void updateConnectButton() {
        if (StandaloneMultiPlayerESP.isEspEnabled()) {
            this.connectButton.method_25355(class_2561.method_43471("screen.multipleplayeresp.config.reconnect"));
        } else {
            this.connectButton.method_25355(class_2561.method_43471("screen.multipleplayeresp.config.connect"));
        }

        if (this.disconnectButton != null) {
            this.disconnectButton.field_22763 = StandaloneMultiPlayerESP.isEspEnabled()
                || StandaloneMultiPlayerESP.getNetworkManager().isConnected();
        }
    }

    private void disconnectFromServer() {
        StandaloneMultiPlayerESP.setEspEnabled(false);
        StandaloneMultiPlayerESP.getNetworkManager().disconnect();
        updateConnectionStatus();
        updateConnectionStatusWidget();
        updateConnectButton();
    }
    
    private void openDisplaySettings() {
        class_310.method_1551().method_1507(new PlayerESPDisplayConfigScreen(this));
    }

    private void openNetworkSettings() {
        class_310.method_1551().method_1507(new PlayerESPNetworkConfigScreen(this));
    }

    /**
     * 更新连接状态文本
     */
    private void updateConnectionStatus() {
        PlayerESPNetworkManager networkManager = StandaloneMultiPlayerESP.getNetworkManager();
        if (networkManager.isConnected()) {
            this.currentConnectionStatus = "Connected";
        } else if (!networkManager.getLastConnectionError().isBlank()) {
            this.currentConnectionStatus = "Failed";
        } else {
            this.currentConnectionStatus = "Disconnected";
        }
    }
    
    /**
     * 添加连接状态显示组件
     */
    private void addConnectionStatusWidget() {
        int componentX = getComponentX();
        int statusY = getNextY();
        this.connectionStatusX = componentX;
        this.connectionStatusY = statusY;
        
        this.connectionStatusWidget = new class_7842(
            componentX, 
            statusY, 
            COMPONENT_WIDTH, 
            COMPONENT_HEIGHT, 
            class_2561.method_43469("screen.multipleplayeresp.config.connection_status", 
                class_2561.method_43471("connection.status." + this.currentConnectionStatus.toLowerCase())), 
            this.field_22793
        );
        
        // 设置文本对齐和颜色
        this.connectionStatusWidget.method_48597();
        updateConnectionStatusWidget();
        
        this.method_37063(this.connectionStatusWidget);
    }

    private void addSaveHintWidget() {
        int componentX = getComponentX();
        int hintY = getNextY();
        this.saveHintWidget = new class_7842(
            componentX,
            hintY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.save_required_hint"),
            this.field_22793
        );
        this.saveHintWidget.method_48597();
        updateSaveHintWidget();
        updateSaveButton();
        this.method_37063(this.saveHintWidget);
    }

    private void updateSaveHintWidget() {
        if (this.saveHintWidget == null) {
            return;
        }
        boolean hasChanges = hasUnsavedChanges();
        this.saveHintWidget.field_22764 = hasChanges;
        if (hasChanges) {
            this.saveHintWidget.method_25355(class_2561.method_43471("screen.multipleplayeresp.config.save_required_hint"));
            this.saveHintWidget.method_46438(SAVE_HINT_COLOR_HIGHLIGHT);
        }
    }

    private void updateSaveButton() {
        if (this.exitSaveButton == null) {
            return;
        }
        if (hasUnsavedChanges()) {
            this.exitSaveButton.method_25355(
                class_2561.method_43471("screen.multipleplayeresp.config.save_network_settings").method_27692(class_124.field_1060)
            );
        } else {
            this.exitSaveButton.method_25355(class_2561.method_43471("screen.multipleplayeresp.config.save_network_settings"));
        }
    }

    private boolean hasUnsavedChanges() {
        String currentRoomCode = this.roomCodeField == null ? this.originalRoomCode : this.roomCodeField.method_1882().trim();
        if (!currentRoomCode.equals(this.originalRoomCode)) {
            return true;
        }

        String currentUrl = this.urlField == null ? this.originalURL : this.urlField.method_1882().trim();
        if (!currentUrl.equals(this.originalURL)) {
            return true;
        }

        return false;
    }
    
    /**
     * 更新连接状态显示组件的颜色和文本
     */
    private void updateConnectionStatusWidget() {
        if (this.connectionStatusWidget != null) {
            // 根据连接状态设置颜色
            int color;
            if (this.currentConnectionStatus.equals("Connected")) {
                color = 0x00FF00;
            } else if (this.currentConnectionStatus.equals("Failed")) {
                color = 0xFFAA00;
            } else {
                color = 0xFF0000;
            }
            
            this.connectionStatusWidget.method_46438(color);
            
            // 更新文本
            if (this.currentConnectionStatus.equals("Failed")) {
                this.connectionStatusWidget.method_25355(
                    class_2561.method_43471("screen.multipleplayeresp.config.connection_failed_short")
                );
            } else {
                this.connectionStatusWidget.method_25355(
                    class_2561.method_43469("screen.multipleplayeresp.config.connection_status",
                        class_2561.method_43471("connection.status." + this.currentConnectionStatus.toLowerCase()))
                );
            }
        }
    }

    private boolean isMouseOverConnectionStatus(int mouseX, int mouseY) {
        return this.connectionStatusWidget != null
            && mouseX >= this.connectionStatusX
            && mouseX < this.connectionStatusX + COMPONENT_WIDTH
            && mouseY >= this.connectionStatusY
            && mouseY < this.connectionStatusY + COMPONENT_HEIGHT;
    }

    private List<class_2561> splitTooltipLines(String content, int maxCharsPerLine) {
        List<class_2561> lines = new ArrayList<>();
        if (content == null || content.isBlank()) {
            lines.add(class_2561.method_43471("screen.multipleplayeresp.config.unknown_error"));
            return lines;
        }

        String[] rawLines = content.split("\\R");
        for (String rawLine : rawLines) {
            if (rawLine.length() <= maxCharsPerLine) {
                lines.add(class_2561.method_30163(rawLine));
                continue;
            }

            int start = 0;
            while (start < rawLine.length()) {
                int end = Math.min(start + maxCharsPerLine, rawLine.length());
                lines.add(class_2561.method_30163(rawLine.substring(start, end)));
                start = end;
            }
        }

        if (lines.isEmpty()) {
            lines.add(class_2561.method_30163(content));
        }
        return lines;
    }
    
    @Override
    public void method_25393() {
        super.method_25393();
        
        // 更新连接按钮状态
        updateConnectButton();
        updateSaveHintWidget();
        updateSaveButton();
    }
}
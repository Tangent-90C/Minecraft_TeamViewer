package fun.prof_chen.teamviewer.multipleplayeresp.ui;

import fun.prof_chen.teamviewer.multipleplayeresp.config.Config;
import fun.prof_chen.teamviewer.multipleplayeresp.core.StandaloneMultiPlayerESP;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class PlayerESPDisplayConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 renderDistanceField;
    private class_342 tracerTopOffsetField;
    private class_4185 tracerStartModeButton;
    private class_4185 showBoxesButton;
    private class_4185 showLinesButton;
    private class_4185 xrayMarkersAndBoxesButton;
    private class_4185 colorSettingsButton;
    private class_4185 waypointSettingsButton;

    private static final int COMPONENT_WIDTH = 170;
    private static final int COMPONENT_HEIGHT = 20;
    private static final int COMPONENT_SPACING = 30;
    private static final int LABEL_SPACING = 12;
    private static final int BUTTON_SPACING = 25;
    private static final int COLUMN_GAP = 6;
    private int startY;
    private int currentY;

    public PlayerESPDisplayConfigScreen(class_437 parent) {
        super(class_2561.method_43471("screen.multipleplayeresp.display_config.title"));
        this.parent = parent;
    }

    private void calculateLayout() {
        int totalHeight = 0;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;

        startY = (this.field_22790 - totalHeight) / 2;
        currentY = startY;
    }

    private int getNextY() {
        int result = currentY;
        currentY += COMPONENT_SPACING;
        return result;
    }

    private int getNextButtonY() {
        int result = currentY;
        currentY += BUTTON_SPACING;
        return result;
    }

    private int getLeftColumnX() {
        int totalWidth = COMPONENT_WIDTH * 2 + COLUMN_GAP;
        return (this.field_22789 - totalWidth) / 2;
    }

    private int getRightColumnX() {
        return getLeftColumnX() + COMPONENT_WIDTH + COLUMN_GAP;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        calculateLayout();
        currentY += COMPONENT_SPACING;

        int leftX = getLeftColumnX();
        int rightX = getRightColumnX();

        int firstFieldY = getNextY();
        this.renderDistanceField = new class_342(
            this.field_22793,
            leftX,
            firstFieldY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.render_distance")
        );
        this.renderDistanceField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getRenderDistance()));
        this.renderDistanceField.method_1880(100);
        this.renderDistanceField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.render_distance_hint"));
        this.method_37063(this.renderDistanceField);

        this.method_37063(
            new class_7842(leftX, firstFieldY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.render_distance"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        this.tracerTopOffsetField = new class_342(
            this.field_22793,
            rightX,
            firstFieldY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.tracer_top_offset")
        );
        this.tracerTopOffsetField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getTracerTopOffset()));
        this.tracerTopOffsetField.method_1880(10);
        this.tracerTopOffsetField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.tracer_top_offset_hint"));
        this.method_37063(this.tracerTopOffsetField);

        this.method_37063(
            new class_7842(rightX, firstFieldY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.tracer_top_offset"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        int displayToggleY = getNextButtonY();
        this.showBoxesButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.show_boxes"),
            button -> toggleShowBoxes()
        ).method_46434(leftX, displayToggleY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.showBoxesButton);

        this.showLinesButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.show_tracking_lines"),
            button -> toggleShowLines()
        ).method_46434(rightX, displayToggleY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.showLinesButton);

        int tracerToggleY = getNextButtonY();
        this.tracerStartModeButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.tracer_start_mode"),
            button -> toggleTracerStartMode()
        ).method_46434(leftX, tracerToggleY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.tracerStartModeButton);

        this.xrayMarkersAndBoxesButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.xray_markers_and_boxes"),
            button -> toggleXrayMarkersAndBoxes()
        ).method_46434(rightX, tracerToggleY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.xrayMarkersAndBoxesButton);

        int subSettingsY = getNextButtonY();
        this.colorSettingsButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.color_settings"),
            button -> openColorConfig()
        ).method_46434(leftX, subSettingsY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.colorSettingsButton);

        this.waypointSettingsButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.waypoint_settings"),
            button -> openWaypointConfig()
        ).method_46434(rightX, subSettingsY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.waypointSettingsButton);

        int backButtonY = getNextButtonY();
        this.method_37063(class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.back"),
            button -> method_25419()
        ).method_46434(leftX, backButtonY, COMPONENT_WIDTH * 2 + COLUMN_GAP, COMPONENT_HEIGHT).method_46431());

        updateTracerStartModeButton();
        updateShowBoxesButton();
        updateShowLinesButton();
        updateXrayMarkersAndBoxesButton();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(
            this.field_22793,
            this.field_22785,
            this.field_22789 / 2,
            startY - 30,
            0xFFFFFF
        );

        if (this.renderDistanceField != null && this.renderDistanceField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.render_distance.tooltip", mouseX, mouseY);
            return;
        }
        if (this.tracerTopOffsetField != null && this.tracerTopOffsetField.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.tracer_top_offset.tooltip", mouseX, mouseY);
            return;
        }
        if (this.showBoxesButton != null && this.showBoxesButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.show_boxes.tooltip", mouseX, mouseY);
            return;
        }
        if (this.showLinesButton != null && this.showLinesButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.show_tracking_lines.tooltip", mouseX, mouseY);
            return;
        }
        if (this.xrayMarkersAndBoxesButton != null && this.xrayMarkersAndBoxesButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.xray_markers_and_boxes.tooltip", mouseX, mouseY);
            return;
        }
        if (this.tracerStartModeButton != null && this.tracerStartModeButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.tracer_start_mode.tooltip", mouseX, mouseY);
            return;
        }
        if (this.colorSettingsButton != null && this.colorSettingsButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.color_settings.tooltip", mouseX, mouseY);
            return;
        }
        if (this.waypointSettingsButton != null && this.waypointSettingsButton.method_25405(mouseX, mouseY)) {
            drawTooltip(context, "screen.multipleplayeresp.config.waypoint_settings.tooltip", mouseX, mouseY);
        }
    }

    private void drawTooltip(class_332 context, String key, int mouseX, int mouseY) {
        String text = class_2561.method_43471(key).getString();
        if (text == null || text.isBlank()) {
            return;
        }
        List<class_2561> lines = splitTooltipLines(text, 42);
        context.method_51434(this.field_22793, lines, mouseX, mouseY);
    }

    private List<class_2561> splitTooltipLines(String input, int maxChars) {
        List<class_2561> lines = new ArrayList<>();
        if (input == null || input.isBlank()) {
            return lines;
        }
        String[] words = input.trim().split("\\s+");
        StringBuilder currentLine = new StringBuilder();
        for (String word : words) {
            if (currentLine.length() == 0) {
                currentLine.append(word);
                continue;
            }
            if (currentLine.length() + 1 + word.length() <= maxChars) {
                currentLine.append(' ').append(word);
            } else {
                lines.add(class_2561.method_30163(currentLine.toString()));
                currentLine.setLength(0);
                currentLine.append(word);
            }
        }
        if (currentLine.length() > 0) {
            lines.add(class_2561.method_30163(currentLine.toString()));
        }
        return lines;
    }

    @Override
    public void method_25419() {
        applyFieldValues();
        class_310.method_1551().method_1507(this.parent);
    }

    private void openColorConfig() {
        class_310.method_1551().method_1507(new PlayerESPColorConfigScreen(this));
    }

    private void openWaypointConfig() {
        class_310.method_1551().method_1507(new PlayerESPWaypointConfigScreen(this));
    }

    private void toggleTracerStartMode() {
        Config config = StandaloneMultiPlayerESP.getConfig();
        if (config.isTracerStartTop()) {
            config.setTracerStartMode(Config.TRACER_START_CROSSHAIR);
        } else {
            config.setTracerStartMode(Config.TRACER_START_TOP);
        }
        updateTracerStartModeButton();
    }

    private void updateTracerStartModeButton() {
        if (this.tracerStartModeButton != null) {
            Config config = StandaloneMultiPlayerESP.getConfig();
            String modeKey = config.isTracerStartTop()
                ? "screen.multipleplayeresp.config.tracer_start_mode.top"
                : "screen.multipleplayeresp.config.tracer_start_mode.crosshair";
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.tracer_start_mode").getString()
                + ": "
                + class_2561.method_43471(modeKey).getString();
            this.tracerStartModeButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void toggleShowBoxes() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isShowBoxes();
        StandaloneMultiPlayerESP.getConfig().setShowBoxes(!currentStatus);
        updateShowBoxesButton();
    }

    private void toggleShowLines() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isShowLines();
        StandaloneMultiPlayerESP.getConfig().setShowLines(!currentStatus);
        updateShowLinesButton();
    }

    private void updateShowBoxesButton() {
        if (this.showBoxesButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isShowBoxes();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.show_boxes").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.showBoxesButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void updateShowLinesButton() {
        if (this.showLinesButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isShowLines();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.show_tracking_lines").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.showLinesButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void toggleXrayMarkersAndBoxes() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isXrayMarkersAndBoxes();
        StandaloneMultiPlayerESP.getConfig().setXrayMarkersAndBoxes(!currentStatus);
        updateXrayMarkersAndBoxesButton();
    }

    private void updateXrayMarkersAndBoxesButton() {
        if (this.xrayMarkersAndBoxesButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isXrayMarkersAndBoxes();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.xray_markers_and_boxes").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.xrayMarkersAndBoxesButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void applyFieldValues() {
        try {
            String renderDistanceStr = this.renderDistanceField.method_1882().trim();
            if (!renderDistanceStr.isEmpty()) {
                int renderDistance = Integer.parseInt(renderDistanceStr);
                if (renderDistance > 0) {
                    StandaloneMultiPlayerESP.getConfig().setRenderDistance(renderDistance);
                }
            }

            String tracerTopOffsetStr = this.tracerTopOffsetField.method_1882().trim();
            if (!tracerTopOffsetStr.isEmpty()) {
                double tracerTopOffset = Double.parseDouble(tracerTopOffsetStr);
                StandaloneMultiPlayerESP.getConfig().setTracerTopOffset(tracerTopOffset);
            }
        } catch (NumberFormatException e) {
        }
    }

    @Override
    public void method_25393() {
        super.method_25393();
        updateTracerStartModeButton();
        updateShowBoxesButton();
        updateShowLinesButton();
        updateXrayMarkersAndBoxesButton();
    }
}
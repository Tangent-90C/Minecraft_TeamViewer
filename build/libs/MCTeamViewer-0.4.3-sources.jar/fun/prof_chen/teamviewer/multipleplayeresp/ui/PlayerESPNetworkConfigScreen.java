package fun.prof_chen.teamviewer.multipleplayeresp.ui;

import fun.prof_chen.teamviewer.multipleplayeresp.core.StandaloneMultiPlayerESP;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class PlayerESPNetworkConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 updateIntervalField;
    private class_4185 uploadEntitiesButton;
    private class_4185 uploadSharedWaypointsButton;
    private class_4185 preferLocalDataForEspButton;
    private class_4185 useSystemProxyButton;

    private static final int COMPONENT_WIDTH = 200;
    private static final int COMPONENT_HEIGHT = 20;
    private static final int COMPONENT_SPACING = 30;
    private static final int LABEL_SPACING = 12;
    private static final int BUTTON_SPACING = 25;
    private int startY;
    private int currentY;

    public PlayerESPNetworkConfigScreen(class_437 parent) {
        super(class_2561.method_43471("screen.multipleplayeresp.network_config.title"));
        this.parent = parent;
    }

    private void calculateLayout() {
        int totalHeight = 0;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;
        totalHeight += BUTTON_SPACING;

        startY = (this.field_22790 - totalHeight) / 2;
        currentY = startY;
    }

    private int getNextY() {
        int result = currentY;
        currentY += COMPONENT_SPACING;
        return result;
    }

    private int getNextButtonY() {
        int result = currentY;
        currentY += BUTTON_SPACING;
        return result;
    }

    private int getComponentX() {
        return (this.field_22789 - COMPONENT_WIDTH) / 2;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        calculateLayout();
        currentY += COMPONENT_SPACING;

        int componentX = getComponentX();

        int updateIntervalY = getNextY();
        this.updateIntervalField = new class_342(
            this.field_22793,
            componentX,
            updateIntervalY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.config.update_interval")
        );
        this.updateIntervalField.method_1852(String.valueOf(StandaloneMultiPlayerESP.getConfig().getUpdateInterval()));
        this.updateIntervalField.method_1880(5);
        this.updateIntervalField.method_47404(class_2561.method_43471("screen.multipleplayeresp.config.update_interval_hint"));
        this.method_37063(this.updateIntervalField);

        this.method_37063(
            new class_7842(componentX, updateIntervalY - LABEL_SPACING, COMPONENT_WIDTH, 12,
                class_2561.method_43471("screen.multipleplayeresp.config.update_interval"), this.field_22793)
                .method_48596()
                .method_46438(0xFFFFFF)
        );

        int uploadEntitiesY = getNextButtonY();
        this.uploadEntitiesButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.upload_entities"),
            button -> toggleUploadEntities()
        ).method_46434(componentX, uploadEntitiesY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.uploadEntitiesButton);

        int uploadSharedWaypointsY = getNextButtonY();
        this.uploadSharedWaypointsButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.upload_shared_waypoints"),
            button -> toggleUploadSharedWaypoints()
        ).method_46434(componentX, uploadSharedWaypointsY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.uploadSharedWaypointsButton);

        int preferLocalDataY = getNextButtonY();
        this.preferLocalDataForEspButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.prefer_local_data_for_esp"),
            button -> togglePreferLocalDataForEsp()
        ).method_46434(componentX, preferLocalDataY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.preferLocalDataForEspButton);

        int useSystemProxyY = getNextButtonY();
        this.useSystemProxyButton = class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.use_system_proxy"),
            button -> toggleUseSystemProxy()
        ).method_46434(componentX, useSystemProxyY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431();
        this.method_37063(this.useSystemProxyButton);

        int backButtonY = getNextButtonY();
        this.method_37063(class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.back"),
            button -> method_25419()
        ).method_46434(componentX, backButtonY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431());

        updateUploadEntitiesButton();
        updateUploadSharedWaypointsButton();
        updatePreferLocalDataForEspButton();
        updateUseSystemProxyButton();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(
            this.field_22793,
            this.field_22785,
            this.field_22789 / 2,
            startY - 30,
            0xFFFFFF
        );
    }

    @Override
    public void method_25419() {
        applyFieldValues();
        class_310.method_1551().method_1507(this.parent);
    }

    private void applyFieldValues() {
        try {
            String updateIntervalStr = this.updateIntervalField.method_1882().trim();
            if (!updateIntervalStr.isEmpty()) {
                int updateInterval = Integer.parseInt(updateIntervalStr);
                if (updateInterval > 0) {
                    StandaloneMultiPlayerESP.getConfig().setUpdateInterval(updateInterval);
                }
            }
        } catch (NumberFormatException e) {
            // 如果输入格式不正确，忽略错误并使用原始值
        }
    }

    private void toggleUploadEntities() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isUploadEntities();
        StandaloneMultiPlayerESP.getConfig().setUploadEntities(!currentStatus);
        updateUploadEntitiesButton();
    }

    private void toggleUploadSharedWaypoints() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isUploadSharedWaypoints();
        StandaloneMultiPlayerESP.getConfig().setUploadSharedWaypoints(!currentStatus);
        updateUploadSharedWaypointsButton();
    }

    private void toggleUseSystemProxy() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isUseSystemProxy();
        StandaloneMultiPlayerESP.getConfig().setUseSystemProxy(!currentStatus);
        updateUseSystemProxyButton();
    }

    private void togglePreferLocalDataForEsp() {
        boolean currentStatus = StandaloneMultiPlayerESP.getConfig().isPreferLocalDataForEsp();
        StandaloneMultiPlayerESP.getConfig().setPreferLocalDataForEsp(!currentStatus);
        updatePreferLocalDataForEspButton();
    }

    private void updateUploadEntitiesButton() {
        if (this.uploadEntitiesButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isUploadEntities();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.upload_entities").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.uploadEntitiesButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void updateUploadSharedWaypointsButton() {
        if (this.uploadSharedWaypointsButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isUploadSharedWaypoints();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.upload_shared_waypoints").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.uploadSharedWaypointsButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void updateUseSystemProxyButton() {
        if (this.useSystemProxyButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isUseSystemProxy();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.use_system_proxy").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.useSystemProxyButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    private void updatePreferLocalDataForEspButton() {
        if (this.preferLocalDataForEspButton != null) {
            boolean isEnabled = StandaloneMultiPlayerESP.getConfig().isPreferLocalDataForEsp();
            String buttonText = class_2561.method_43471("screen.multipleplayeresp.config.prefer_local_data_for_esp").getString();
            buttonText += isEnabled ? " [ON]" : " [OFF]";
            this.preferLocalDataForEspButton.method_25355(class_2561.method_30163(buttonText));
        }
    }

    @Override
    public void method_25393() {
        super.method_25393();
        updateUploadEntitiesButton();
        updateUploadSharedWaypointsButton();
        updatePreferLocalDataForEspButton();
        updateUseSystemProxyButton();
    }
}

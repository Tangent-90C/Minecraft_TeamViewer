package fun.prof_chen.teamviewer.multipleplayeresp.ui;

import fun.prof_chen.teamviewer.multipleplayeresp.core.StandaloneMultiPlayerESP;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class PlayerESPColorConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 boxColorField;
    private class_342 lineColorField;
    private class_342 friendlyTeamColorField;
    private class_342 neutralTeamColorField;
    private class_342 enemyTeamColorField;

    private static final int COMPONENT_WIDTH = 200;
    private static final int COMPONENT_HEIGHT = 20;
    private static final int COMPONENT_SPACING = 30;
    private static final int LABEL_SPACING = 12;
    private int startY;
    private int currentY;

    public PlayerESPColorConfigScreen(class_437 parent) {
        super(class_2561.method_43471("screen.multipleplayeresp.color_config.title"));
        this.parent = parent;
    }

    private void calculateLayout() {
        int totalHeight = 0;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;
        totalHeight += COMPONENT_SPACING;

        startY = (this.field_22790 - totalHeight) / 2;
        currentY = startY;
    }

    private int getNextY() {
        int result = currentY;
        currentY += COMPONENT_SPACING;
        return result;
    }

    private int getComponentX() {
        return (this.field_22789 - COMPONENT_WIDTH) / 2;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        calculateLayout();
        currentY += COMPONENT_SPACING;

        int componentX = getComponentX();

        int boxColorY = getNextY();
        this.boxColorField = new class_342(
            this.field_22793,
            componentX,
            boxColorY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.color_config.box_color")
        );
        this.boxColorField.method_1852(String.format("0x%08X", StandaloneMultiPlayerESP.getConfig().getBoxColor()));
        this.method_37063(this.boxColorField);
        this.method_37063(new class_7842(componentX, boxColorY - LABEL_SPACING, COMPONENT_WIDTH, 12,
            class_2561.method_43471("screen.multipleplayeresp.color_config.box_color"), this.field_22793)
            .method_48596()
            .method_46438(0xA0A0A0));

        int lineColorY = getNextY();
        this.lineColorField = new class_342(
            this.field_22793,
            componentX,
            lineColorY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.color_config.line_color")
        );
        this.lineColorField.method_1852(String.format("0x%08X", StandaloneMultiPlayerESP.getConfig().getLineColor()));
        this.method_37063(this.lineColorField);
        this.method_37063(new class_7842(componentX, lineColorY - LABEL_SPACING, COMPONENT_WIDTH, 12,
            class_2561.method_43471("screen.multipleplayeresp.color_config.line_color"), this.field_22793)
            .method_48596()
            .method_46438(0xA0A0A0));

        int friendlyColorY = getNextY();
        this.friendlyTeamColorField = new class_342(
            this.field_22793,
            componentX,
            friendlyColorY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.color_config.friendly_team_color")
        );
        this.friendlyTeamColorField.method_1852(String.format("0x%08X", StandaloneMultiPlayerESP.getConfig().getFriendlyTeamColor()));
        this.method_37063(this.friendlyTeamColorField);
        this.method_37063(new class_7842(componentX, friendlyColorY - LABEL_SPACING, COMPONENT_WIDTH, 12,
            class_2561.method_43471("screen.multipleplayeresp.color_config.friendly_team_color"), this.field_22793)
            .method_48596()
            .method_46438(0xA0A0A0));

        int neutralColorY = getNextY();
        this.neutralTeamColorField = new class_342(
            this.field_22793,
            componentX,
            neutralColorY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.color_config.neutral_team_color")
        );
        this.neutralTeamColorField.method_1852(String.format("0x%08X", StandaloneMultiPlayerESP.getConfig().getNeutralTeamColor()));
        this.method_37063(this.neutralTeamColorField);
        this.method_37063(new class_7842(componentX, neutralColorY - LABEL_SPACING, COMPONENT_WIDTH, 12,
            class_2561.method_43471("screen.multipleplayeresp.color_config.neutral_team_color"), this.field_22793)
            .method_48596()
            .method_46438(0xA0A0A0));

        int enemyColorY = getNextY();
        this.enemyTeamColorField = new class_342(
            this.field_22793,
            componentX,
            enemyColorY,
            COMPONENT_WIDTH,
            COMPONENT_HEIGHT,
            class_2561.method_43471("screen.multipleplayeresp.color_config.enemy_team_color")
        );
        this.enemyTeamColorField.method_1852(String.format("0x%08X", StandaloneMultiPlayerESP.getConfig().getEnemyTeamColor()));
        this.method_37063(this.enemyTeamColorField);
        this.method_37063(new class_7842(componentX, enemyColorY - LABEL_SPACING, COMPONENT_WIDTH, 12,
            class_2561.method_43471("screen.multipleplayeresp.color_config.enemy_team_color"), this.field_22793)
            .method_48596()
            .method_46438(0xA0A0A0));

        int backButtonY = getNextY();
        this.method_37063(class_4185.method_46430(
            class_2561.method_43471("screen.multipleplayeresp.config.back"),
            button -> method_25419()
        ).method_46434(componentX, backButtonY, COMPONENT_WIDTH, COMPONENT_HEIGHT).method_46431());

    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(
            this.field_22793,
            this.field_22785,
            this.field_22789 / 2,
            startY - 30,
            0xFFFFFF
        );
    }

    @Override
    public void method_25419() {
        applyFieldValues();
        class_310.method_1551().method_1507(this.parent);
    }

    private void applyFieldValues() {
        try {
            Integer boxColor = parseColorValue(this.boxColorField.method_1882());
            if (boxColor != null) {
                StandaloneMultiPlayerESP.getConfig().setBoxColor(boxColor);
            }

            Integer lineColor = parseColorValue(this.lineColorField.method_1882());
            if (lineColor != null) {
                StandaloneMultiPlayerESP.getConfig().setLineColor(lineColor);
            }

            Integer friendlyColor = parseColorValue(this.friendlyTeamColorField.method_1882());
            if (friendlyColor != null) {
                StandaloneMultiPlayerESP.getConfig().setFriendlyTeamColor(friendlyColor);
            }

            Integer neutralColor = parseColorValue(this.neutralTeamColorField.method_1882());
            if (neutralColor != null) {
                StandaloneMultiPlayerESP.getConfig().setNeutralTeamColor(neutralColor);
            }

            Integer enemyColor = parseColorValue(this.enemyTeamColorField.method_1882());
            if (enemyColor != null) {
                StandaloneMultiPlayerESP.getConfig().setEnemyTeamColor(enemyColor);
            }
        } catch (NumberFormatException e) {
        }
    }

    private Integer parseColorValue(String rawText) {
        if (rawText == null) {
            return null;
        }
        String text = rawText.trim();
        if (text.isEmpty()) {
            return null;
        }

        if (text.startsWith("0x") || text.startsWith("0X")) {
            return (int) Long.parseLong(text.substring(2), 16);
        }
        if (text.startsWith("#")) {
            String hex = text.substring(1);
            if (hex.length() == 6) {
                return (0xFF << 24) | Integer.parseInt(hex, 16);
            }
            if (hex.length() == 8) {
                return (int) Long.parseLong(hex, 16);
            }
            return null;
        }
        return (int) Long.parseLong(text, 16);
    }
}

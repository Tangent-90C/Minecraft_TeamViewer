package fun.prof_chen.teamviewer.multipleplayeresp.core;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_634;
import net.minecraft.class_640;
import net.minecraft.class_742;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import fun.prof_chen.teamviewer.multipleplayeresp.bridge.XaeroWaypointShareBridge;
import fun.prof_chen.teamviewer.multipleplayeresp.bridge.XaeroWorldMapBridge;
import fun.prof_chen.teamviewer.multipleplayeresp.bridge.JourneyMapBridge;
import fun.prof_chen.teamviewer.multipleplayeresp.config.Config;
import fun.prof_chen.teamviewer.multipleplayeresp.model.RemotePlayerInfo;
import fun.prof_chen.teamviewer.multipleplayeresp.model.ReportDataSchemas;
import fun.prof_chen.teamviewer.multipleplayeresp.model.SharedWaypointInfo;
import fun.prof_chen.teamviewer.multipleplayeresp.network.PlayerESPNetworkManager;
import fun.prof_chen.teamviewer.multipleplayeresp.ui.PlayerESPConfigScreen;
import fun.prof_chen.teamviewer.multipleplayeresp.render.UnifiedRenderModule;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class StandaloneMultiPlayerESP implements ClientModInitializer {
	public static final String MOD_ID = "multipleplayeresp";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	
	public static final class_310 MC = class_310.method_1551();
	
	// Mod keybinding
	private static class_304 toggleKey;
	private static class_304 configKey;
	private static class_304 markKey;
	
	// Player position tracking
	private static final Map<UUID, class_243> playerPositions = new ConcurrentHashMap<>();
	private static final Map<UUID, RemotePlayerInfo> remotePlayers = new ConcurrentHashMap<>();
	private static final Map<UUID, class_243> serverPlayerPositions = new ConcurrentHashMap<>();
	private static final Map<String, SharedWaypointInfo> sharedWaypoints = new ConcurrentHashMap<>();
	private static final Map<String, class_243> trackedEntityWaypointLastPositions = new ConcurrentHashMap<>();
	
	// Performance optimization: entity UUID -> position cache (updated each tick)
	private static final Map<UUID, class_1297> entityUuidCache = new ConcurrentHashMap<>();
	private static String lastCachedDimension = null;
	
	// Network manager
	private static PlayerESPNetworkManager networkManager;
	
	// Config
	private static Config config;
	
	// ESP settings
	private static boolean espEnabled = false;
	private static final boolean useServerPositions = false;

    // 用于控制位置更新频率
	private static int tickCounter = 0;

	// 鼠标中键双击报点
	private static final long MARK_DOUBLE_CLICK_MS = 300L;
	private static final double MARK_RAYCAST_DISTANCE = 256.0D;
	private static final double MARK_CANCEL_BASE_RADIUS = 1.2D;
	private static final double MARK_CANCEL_RADIUS_PER_BLOCK = 0.02D;
	private static final double MARK_CANCEL_MAX_RADIUS = 4.0D;
	private static final int MARKER_COLOR_RGB = 0xFF8C00;
	private static boolean middlePressedLastTick = false;
	private static long lastMiddleClickTs = 0L;
	
	@Override
	public void onInitializeClient() {
		// 初始化客户端功能
		LOGGER.info("Initializing MultiPlayer ESP mod");
		
		// 加载配置
		config = Config.load();
		
		// 初始化网络管理器
		networkManager = new PlayerESPNetworkManager(playerPositions, remotePlayers);
		PlayerESPNetworkManager.setConfig(config);
		registerWaypointSyncListener();
		
		// 注册按键绑定
		toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.multipleplayeresp.toggle",
			class_3675.class_307.field_1668,
			GLFW.GLFW_KEY_UNKNOWN, // 默认不绑定，玩家自行设置
			"category.multipleplayeresp.general"
		));
		
		// 注册配置界面按键
		configKey = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.multipleplayeresp.config",
			class_3675.class_307.field_1668,
			GLFW.GLFW_KEY_O, // 默认绑定O键
			"category.multipleplayeresp.general"
		));

		// 注册报点按键（可在游戏控制设置中自定义）
		markKey = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.multipleplayeresp.mark",
			class_3675.class_307.field_1668,
			GLFW.GLFW_KEY_UNKNOWN, // 默认不绑定，玩家自行设置
			"category.multipleplayeresp.general"
		));
		
		// 注册客户端tick事件
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			// 先消费网络线程投递的任务：保证网络状态与共享缓存在主线程串行更新，
			// 再执行本 tick 的输入处理、世界采集与上行发送，避免并发读写冲突。
			if (networkManager != null) {
				networkManager.pumpMainThreadTasks();
			}

			// 处理按键输入
			while (toggleKey.method_1436()) {
				toggleESP();
			}
			
			// 处理配置界面按键
			while (configKey.method_1436()) {
				openConfigScreen();
			}

			// 处理报点按键（单击触发）
			while (markKey.method_1436()) {
				if (canCreateMark(client)) {
					createAndSyncQuickMark(client);
				}
			}
			
			// 更新玩家位置信息
			updatePlayerPositions();
			updateEntityCache(client);
			handleMiddleMouseDoubleClickMarking(client);
			handleAutoCancelWaypointOnEntityDeath(client);

			// 同步远程玩家到Xaero世界地图
			XaeroWorldMapBridge.tick(resolvePlayersForWorldMapBridge(), espEnabled);
			XaeroWaypointShareBridge.tick(networkManager, espEnabled, config);
			
			// 同步到JourneyMap
			JourneyMapBridge.tick(networkManager, resolvePlayersForWorldMapBridge(), sharedWaypoints, espEnabled);
			
			// 发送玩家位置到服务器
			if (espEnabled && networkManager != null) {
				handleRegistrationAndPositionUpdates();
			}
		});
		
		// 注册世界渲染事件
		WorldRenderEvents.AFTER_ENTITIES.register(context -> {
			if (espEnabled) {
				renderESP(context);
			}
		});
		
		LOGGER.info("MultiPlayer ESP mod initialized");
	}
	
	private void toggleESP() {
		espEnabled = !espEnabled;
		
		if (espEnabled) {
			// 启用ESP，连接到服务器
			networkManager.connect();
			LOGGER.info("MultiPlayer ESP enabled");
		} else {
			// 禁用ESP，断开连接
			networkManager.disconnect();
			sharedWaypoints.clear();
			trackedEntityWaypointLastPositions.clear();
			JourneyMapBridge.reset();
			LOGGER.info("MultiPlayer ESP disabled");
		}
		
		// 重置计数器
		tickCounter = 0;
	}
	
	private void openConfigScreen() {
		MC.method_1507(new PlayerESPConfigScreen(MC.field_1755));
	}
	
	private Map<UUID, Map<String, Object>> collectPlayerData(class_310 client) {
		Map<UUID, Map<String, Object>> players = new HashMap<>();
		if (client.field_1687 != null) {
			for (class_742 p : client.field_1687.method_18456()) {
				UUID pid = p.method_5667();
				class_243 pos = p.method_19538();
				class_243 vel = p.method_18798();
				boolean isRiding = isPlayerRiding(p);
				ReportDataSchemas.PlayerDataPayload payload = new ReportDataSchemas.PlayerDataPayload(
						pos.field_1352,
						pos.field_1351,
						pos.field_1350,
						vel.field_1352,
						vel.field_1351,
						vel.field_1350,
						p.method_37908().method_27983().method_29177().toString(),
						p.method_5477().getString(),
						pid.toString(),
						p.method_6032(),
						p.method_6063(),
						0,
						isRiding,
						p.method_17681(),
						p.method_17682());
				players.put(pid, payload.toMap());
			}
		}
		return players;
	}

	private boolean isPlayerRiding(class_742 player) {
		if (player == null) {
			return false;
		}
		class_1297 vehicle = player.method_5854();
		if (vehicle == null || vehicle.method_5864() == null) {
			return false;
		}
		String entityTypeText = String.valueOf(vehicle.method_5864()).toLowerCase(Locale.ROOT);
		return entityTypeText.contains("horse");
	}
	
	private Map<String, Map<String, Object>> collectEntityData(class_310 client) {
		Map<String, Map<String, Object>> entities = new HashMap<>();
		if (client.field_1687 != null) {
			for (class_1297 entity : client.field_1687.method_18112()) {
				if (entity == client.field_1724) continue;
				String entityId = entity.method_5667().toString();
				class_243 ePos = entity.method_19538();
				class_243 eVel = entity.method_18798();
				String eDim = entity.method_37908().method_27983().method_29177().toString();
				String entityType = entity.method_5864().toString();
				ReportDataSchemas.EntityDataPayload payload = new ReportDataSchemas.EntityDataPayload(
						ePos.field_1352,
						ePos.field_1351,
						ePos.field_1350,
						eVel.field_1352,
						eVel.field_1351,
						eVel.field_1350,
						eDim,
						entityType,
						entity.method_16914() ? entity.method_5476().getString() : null,
						entity.method_17681(),
						entity.method_17682());
				entities.put(entityId, payload.toMap());
			}
		}
		return entities;
	}
	
	private void updatePlayerPositions() {
		class_310 client = class_310.method_1551();
		if (client.field_1687 != null && client.field_1724 != null) {
			// 更新服务器端玩家位置
			serverPlayerPositions.clear();
			for (class_742 player : client.field_1687.method_18456()) {
				if (player != client.field_1724) { // 不包括自己
					serverPlayerPositions.put(player.method_5667(), player.method_19538());
				}
			}
		}
	}
	
	private void handleRegistrationAndPositionUpdates() {
		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || !client.field_1724.method_5805()) {
			return;
		}
		
		tickCounter++;
		
		// 连接成功后按间隔发送玩家更新与实体更新（submitPlayerId 为本地玩家 UUID）
		int targetInterval = networkManager.isConnected()
				? networkManager.getNegotiatedReportIntervalTicks()
				: config.getUpdateInterval();
		if (networkManager.isConnected() && tickCounter >= Math.max(1, targetInterval)) {
			tickCounter = 0;
			UUID submitPlayerId = client.field_1724.method_5667();
			networkManager.sendTabPlayersUpdate(submitPlayerId, collectTabPlayers(client));

			// 批量收集所有玩家（含本地）并上传
			Map<UUID, Map<String, Object>> players = collectPlayerData(client);
			networkManager.sendPlayersUpdate(submitPlayerId, players);

			// 收集并上报当前世界中的实体（带 submitPlayerId）
			if (config.isUploadEntities() && client.field_1687 != null) {
				Map<String, Map<String, Object>> entities = collectEntityData(client);
				networkManager.sendEntitiesUpdate(submitPlayerId, entities);
			}
		}
	}

	private List<Map<String, Object>> collectTabPlayers(class_310 client) {
		List<Map<String, Object>> result = new ArrayList<>();
		if (client == null) return result;

		class_634 handler = client.method_1562();
		if (handler == null) return result;

		try {
			Collection<class_640> entries = handler.method_2880();
			for (class_640 entry : entries) {
				if (entry == null || entry.method_2966() == null) continue;

				String playerId = entry.method_2966().getId() == null
						? null
						: entry.method_2966().getId().toString();

				String profileName = entry.method_2966().getName();
				if (profileName == null || profileName.isBlank()) continue;

				class_268 team = resolvePlayerTeam(client, entry, profileName);

				String prefixText = null;
				String prefixColored = null;

				if (team != null) {
					prefixText = team.method_1197();
					prefixColored = team.method_1144().toString();
				}

				Map<String, Object> node = new HashMap<>();

				if (playerId != null && !playerId.isBlank()) {
					node.put("playerUUID", playerId);
				}

				node.put("name", profileName);

				if (prefixText != null && !prefixText.isBlank()) {
					node.put("prefixText", prefixText);
				}

				if (prefixColored != null && !prefixColored.isBlank()) {
					node.put("prefixColored", prefixColored);
				}

				result.add(node);
			}
		} catch (Exception e) {
			LOGGER.debug("collectTabPlayers failed: {}", e.getMessage());
		}

		return result;
	}

	private class_268 resolvePlayerTeam(class_310 client,
								   class_640 entry,
								   String profileName) {

		// 1. 先用 PlayerListEntry 自带的（最准确）
		class_268 team = entry.method_2955();
		if (team != null) return team;

		// 2. fallback 到客户端 scoreboard
		if (client != null && client.field_1687 != null) {
			class_269 scoreboard = client.field_1687.method_8428();
			if (scoreboard != null) {
				return scoreboard.method_1164(profileName);
			}
		}

		return null;
	}

	private void renderESP(WorldRenderContext context) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1687 == null) return;
		boolean depthTestEnabled = !config.isXrayMarkersAndBoxes();
		
		class_243 cameraPos = context.camera().method_19326();
		Map<UUID, class_243> positions = useServerPositions ? serverPlayerPositions : resolvePlayersForRender();
		
		// 渲染玩家位置框
		for (Map.Entry<UUID, class_243> entry : positions.entrySet()) {
			if (entry.getKey().equals(client.field_1724.method_5667())) {
				continue; // 跳过自己
			}

			String markedTeam = networkManager == null ? null : networkManager.getPlayerMarkTeam(entry.getKey());
			int boxRenderColor = resolveRenderColorByTeam(markedTeam, config.getBoxColor());
			int tracerRenderColor = resolveRenderColorByTeam(markedTeam, config.getLineColor());

			class_243 playerPos = entry.getValue();
			
			// 检查距离
			if (client.field_1724.method_19538().method_1022(playerPos) <= config.getRenderDistance()) {
				// 计算相对位置
				class_243 relativePos = playerPos.method_1020(cameraPos);
				
				// 创建玩家包围盒
				class_238 box = new class_238(
					relativePos.field_1352 - 0.3, relativePos.field_1351, relativePos.field_1350 - 0.3,
					relativePos.field_1352 + 0.3, relativePos.field_1351 + 1.8, relativePos.field_1350 + 0.3
				);
				
				// 绘制包围盒
				if (config.isShowBoxes()) {
					UnifiedRenderModule.drawOutlinedBox(context.matrixStack(), box, boxRenderColor, depthTestEnabled);
				}
				
				// 绘制连线
				if (config.isShowLines()) {
					class_243 targetPos = relativePos.method_1031(0, 1.0, 0);
					class_243 lookVec = client.field_1724.method_5828(1.0F).method_1029();
					class_243 worldUp = new class_243(0, 1, 0);
					class_243 rightVec = lookVec.method_1036(worldUp);
					if (rightVec.method_1027() < 1.0E-6) {
						rightVec = new class_243(1, 0, 0);
					}
					class_243 cameraUpVec = rightVec.method_1029().method_1036(lookVec).method_1029();

					class_243 tracerStart;
					if (config.isTracerStartTop()) {
						tracerStart = lookVec.method_1021(0.6).method_1019(cameraUpVec.method_1021(config.getTracerTopOffset()));
					} else {
						tracerStart = lookVec.method_1021(0.6);
					}
					UnifiedRenderModule.drawTracerLine(context.matrixStack(), tracerStart, targetPos, tracerRenderColor, depthTestEnabled);
				}
			}
		}

		renderSharedWaypointMarkers(context, cameraPos, depthTestEnabled);
	}

	private Map<UUID, class_243> resolvePlayersForRender() {
		if (config == null || !config.isPreferLocalDataForEsp()) {
			return playerPositions;
		}

		Map<UUID, class_243> mergedPositions = new HashMap<>(playerPositions);
		mergedPositions.putAll(serverPlayerPositions);
		return mergedPositions;
	}

	private Map<UUID, RemotePlayerInfo> resolvePlayersForWorldMapBridge() {
		if (config == null || !config.isPreferLocalDataForEsp()) {
			return remotePlayers;
		}

		Map<UUID, RemotePlayerInfo> mergedPlayers = new HashMap<>(remotePlayers);
		class_310 client = class_310.method_1551();
		if (client.field_1687 != null) {
			for (class_742 player : client.field_1687.method_18456()) {
				if (player == null || player == client.field_1724) {
					continue;
				}
				RemotePlayerInfo localInfo = new RemotePlayerInfo(
					player.method_5667(),
					player.method_19538(),
					player.method_37908().method_27983(),
					player.method_5477().getString()
				);
				mergedPlayers.put(player.method_5667(), localInfo);
			}
		}

		return mergedPlayers;
	}

	private int resolveRenderColorByTeam(String teamTag, int fallbackColor) {
		if (teamTag == null || teamTag.isBlank()) {
			return fallbackColor;
		}

		String normalized = teamTag.trim().toLowerCase();
		if ("friendly".equals(normalized) || "friend".equals(normalized) || "ally".equals(normalized)) {
			return config.getFriendlyTeamColor();
		}
		if ("enemy".equals(normalized) || "hostile".equals(normalized)) {
			return config.getEnemyTeamColor();
		}
		if ("neutral".equals(normalized)) {
			return config.getNeutralTeamColor();
		}
		return fallbackColor;
	}

	private void registerWaypointSyncListener() {
		networkManager.addWaypointUpdateListener(new PlayerESPNetworkManager.WaypointUpdateListener() {
			@Override
			public void onWaypointsReceived(Map<String, SharedWaypointInfo> waypoints) {
				if (waypoints == null || waypoints.isEmpty()) {
					return;
				}
				sharedWaypoints.putAll(waypoints);
			}

			@Override
			public void onWaypointsDeleted(List<String> waypointIds) {
				if (waypointIds == null || waypointIds.isEmpty()) {
					return;
				}
				for (String waypointId : waypointIds) {
					sharedWaypoints.remove(waypointId);
					trackedEntityWaypointLastPositions.remove(waypointId);
				}
				XaeroWaypointShareBridge.deleteSharedWaypoints(waypointIds);
			}
		});
	}

	private void handleMiddleMouseDoubleClickMarking(class_310 client) {
		if (config == null) {
			middlePressedLastTick = false;
			return;
		}

		boolean enableDoubleClickMark = config.isEnableMiddleDoubleClickMark();
		boolean enableClickCancel = config.isEnableMiddleClickCancelWaypoint();
		if (!enableDoubleClickMark && !enableClickCancel) {
			middlePressedLastTick = false;
			return;
		}

		if (!canCreateMark(client)) {
			middlePressedLastTick = false;
			return;
		}

		long windowHandle = client.method_22683().method_4490();
		boolean middlePressed = GLFW.glfwGetMouseButton(windowHandle, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;

		if (middlePressed && !middlePressedLastTick) {
			if (enableClickCancel && tryCancelTargetedWaypoint(client)) {
				lastMiddleClickTs = 0L;
				middlePressedLastTick = middlePressed;
				return;
			}
			if (!enableDoubleClickMark) {
				middlePressedLastTick = middlePressed;
				return;
			}

			long now = System.currentTimeMillis();
			if (now - lastMiddleClickTs <= MARK_DOUBLE_CLICK_MS) {
				lastMiddleClickTs = 0L;
				createAndSyncQuickMark(client);
			} else {
				lastMiddleClickTs = now;
			}
		}

		middlePressedLastTick = middlePressed;
	}

	private void handleAutoCancelWaypointOnEntityDeath(class_310 client) {
		if (config == null || !config.isAutoCancelWaypointOnEntityDeath()) {
			return;
		}
		if (client == null || client.field_1724 == null || client.field_1687 == null || sharedWaypoints.isEmpty()) {
			return;
		}

		UUID localPlayerId = client.field_1724.method_5667();
		String currentDimension = client.field_1687.method_27983().method_29177().toString();
		Map<String, class_1297> localEntitiesById = new HashMap<>();
		for (class_1297 entity : client.field_1687.method_18112()) {
			if (entity == null) {
				continue;
			}
			localEntitiesById.put(entity.method_5845(), entity);
		}

		Map<String, class_1309> confirmedDeadEntities = new HashMap<>();
		for (Map.Entry<String, class_1297> entry : localEntitiesById.entrySet()) {
			class_1297 entity = entry.getValue();
			if (!(entity instanceof class_1309 livingEntity)) {
				continue;
			}
			if (!isKillableMarkTarget(entity)) {
				continue;
			}
			if (!isEntityDeathConfirmed(livingEntity)) {
				continue;
			}
			confirmedDeadEntities.put(entry.getKey(), livingEntity);
		}
		if (confirmedDeadEntities.isEmpty()) {
			return;
		}

		List<String> toDelete = new java.util.ArrayList<>();
		List<String> cancelledTargetEntityIds = new java.util.ArrayList<>();
		for (Map.Entry<String, SharedWaypointInfo> entry : sharedWaypoints.entrySet()) {
			String waypointId = entry.getKey();
			SharedWaypointInfo waypoint = entry.getValue();
			if (waypoint == null) {
				continue;
			}
			if (!"entity".equalsIgnoreCase(waypoint.targetType())) {
				continue;
			}
			if (waypoint.dimension() != null && !waypoint.dimension().isBlank() && !waypoint.dimension().equals(currentDimension)) {
				continue;
			}
			String targetEntityId = waypoint.targetEntityId();
			if (targetEntityId == null || targetEntityId.isBlank()) {
				continue;
			}
			if (!confirmedDeadEntities.containsKey(targetEntityId)) {
				continue;
			}

			toDelete.add(waypointId);
			cancelledTargetEntityIds.add(targetEntityId);
		}

		if (toDelete.isEmpty()) {
			return;
		}

		for (String waypointId : toDelete) {
			SharedWaypointInfo removed = sharedWaypoints.remove(waypointId);
			trackedEntityWaypointLastPositions.remove(waypointId);
			XaeroWaypointShareBridge.deleteSharedWaypoint(waypointId);
			if (removed != null && client.field_1724 != null) {
				String removedName = removed.name() == null || removed.name().isBlank() ? waypointId : removed.name();
				client.field_1724.method_7353(class_2561.method_43470("§7[TV] 目标已确认死亡，自动取消报点: " + removedName), true);
			}
		}

		if (networkManager != null && networkManager.isConnected()) {
			networkManager.sendWaypointEntityDeathCancel(localPlayerId, cancelledTargetEntityIds);
		}
	}

	private boolean isKillableMarkTarget(class_1297 entity) {
		return entity instanceof class_1309;
	}

	private boolean isEntityDeathConfirmed(class_1309 livingEntity) {
		return livingEntity.method_6032() <= 0.0F;
	}

	private boolean tryCancelTargetedWaypoint(class_310 client) {
		if (client == null || client.field_1724 == null || client.field_1687 == null || sharedWaypoints.isEmpty()) {
			return false;
		}

		UUID localPlayerId = client.field_1724.method_5667();
		String currentDimension = client.field_1687.method_27983().method_29177().toString();
		class_243 eyePos = client.field_1724.method_5836(1.0F);
		class_243 lookVec = client.field_1724.method_5828(1.0F).method_1029();
		double maxDistance = Math.max(config.getRenderDistance(), MARK_RAYCAST_DISTANCE);

		String selectedWaypointId = null;
		double selectedScore = Double.MAX_VALUE;

		for (Map.Entry<String, SharedWaypointInfo> entry : sharedWaypoints.entrySet()) {
			SharedWaypointInfo waypoint = entry.getValue();
			if (waypoint == null) {
				continue;
			}
			if (waypoint.ownerId() == null || !localPlayerId.equals(waypoint.ownerId())) {
				continue;
			}
			if (waypoint.dimension() != null && !waypoint.dimension().isBlank() && !waypoint.dimension().equals(currentDimension)) {
				continue;
			}

			class_243 waypointPos = resolveWaypointWorldPosition(client, waypoint, currentDimension);
			if (waypointPos == null) {
				continue;
			}

			class_243 toWaypoint = waypointPos.method_1020(eyePos);
			double alongRay = toWaypoint.method_1026(lookVec);
			if (alongRay <= 0.0D || alongRay > maxDistance) {
				continue;
			}

			class_243 closestPoint = eyePos.method_1019(lookVec.method_1021(alongRay));
			double lateralDistance = waypointPos.method_1022(closestPoint);
			double allowedRadius = Math.min(
				MARK_CANCEL_MAX_RADIUS,
				MARK_CANCEL_BASE_RADIUS + alongRay * MARK_CANCEL_RADIUS_PER_BLOCK
			);
			if (lateralDistance > allowedRadius) {
				continue;
			}

			double score = lateralDistance + alongRay * 0.0025D;
			if (score < selectedScore) {
				selectedScore = score;
				selectedWaypointId = entry.getKey();
			}
		}

		if (selectedWaypointId == null) {
			return false;
		}

		SharedWaypointInfo removed = sharedWaypoints.remove(selectedWaypointId);
		trackedEntityWaypointLastPositions.remove(selectedWaypointId);
		XaeroWaypointShareBridge.deleteSharedWaypoint(selectedWaypointId);
		networkManager.sendWaypointsDelete(localPlayerId, List.of(selectedWaypointId));

		if (removed != null) {
			String removedName = removed.name() == null || removed.name().isBlank() ? selectedWaypointId : removed.name();
			client.field_1724.method_7353(class_2561.method_43470("§e[TV] 已取消报点: " + removedName), true);
		}
		return true;
	}

	private boolean canCreateMark(class_310 client) {
		return espEnabled
			&& client != null
			&& client.field_1724 != null
			&& client.field_1687 != null
			&& client.field_1755 == null
			&& networkManager != null
			&& networkManager.isConnected();
	}

	private void createAndSyncQuickMark(class_310 client) {
		if (client.field_1724 == null || client.field_1687 == null) {
			return;
		}

		MarkTarget target = resolveMarkTarget(client);
		if (target == null) {
			client.field_1724.method_7353(class_2561.method_43470("§c[TV] 报点失败：未命中方块或实体"), true);
			return;
		}

		class_243 worldPos = target.position();
		int markX = (int) Math.floor(worldPos.field_1352);
		int markY = (int) Math.floor(worldPos.field_1351);
		int markZ = (int) Math.floor(worldPos.field_1350);

		UUID ownerId = client.field_1724.method_5667();
		String ownerName = client.field_1724.method_5477().getString();
		String dimension = client.field_1687.method_27983().method_29177().toString();
		long createdAt = System.currentTimeMillis();
		String idSource = ownerId + "|" + createdAt + "|" + dimension + "|" + markX + "|" + markY + "|" + markZ;
		String waypointId = UUID.nameUUIDFromBytes(idSource.getBytes(StandardCharsets.UTF_8)).toString();

		int maxQuickMarkCount = config.getMaxQuickMarkCount();
		List<String> overflowQuickWaypointIds = collectOverflowQuickWaypointIdsByOwner(ownerId, waypointId, maxQuickMarkCount);
		if (!overflowQuickWaypointIds.isEmpty()) {
			for (String oldId : overflowQuickWaypointIds) {
				sharedWaypoints.remove(oldId);
			}
			networkManager.sendWaypointsDelete(ownerId, overflowQuickWaypointIds);
		}

		String targetType = target.targetEntity() == null ? "block" : "entity";
		String targetEntityId = target.targetEntity() == null ? null : target.targetEntity().method_5845();
		String targetEntityType = target.targetEntity() == null
				? null
				: target.targetEntity().method_5864().toString();
		String targetEntityName = target.targetEntity() == null
				? null
				: target.targetEntity().method_5476().getString();

		String markName;
		if (target.targetEntity() != null) {
			String displayName = targetEntityName == null || targetEntityName.isBlank() ? "Entity" : targetEntityName;
			markName = "报点[实体] " + displayName;
		} else {
			markName = "报点";
		}

		SharedWaypointInfo waypoint = new SharedWaypointInfo(
			waypointId,
			ownerId,
			ownerName,
			markName,
			"!",
			markX,
			markY,
			markZ,
			dimension,
			MARKER_COLOR_RGB,
			createdAt,
			targetType,
			targetEntityId,
			targetEntityType,
			targetEntityName,
			"quick",
			null,
			null
		);
		sharedWaypoints.put(waypointId, waypoint);

		Map<String, Object> payload = new HashMap<>();
		payload.put("x", markX);
		payload.put("y", markY);
		payload.put("z", markZ);
		payload.put("dimension", dimension);
		payload.put("name", waypoint.name());
		payload.put("symbol", waypoint.symbol());
		payload.put("color", waypoint.color());
		payload.put("ownerId", ownerId.toString());
		payload.put("ownerName", ownerName);
		payload.put("createdAt", createdAt);
		payload.put("ttlSeconds", config.getWaypointTimeoutSeconds());
		payload.put("waypointKind", "quick");
		payload.put("maxQuickMarks", maxQuickMarkCount);
		payload.put("targetType", targetType);
		payload.put("targetEntityId", targetEntityId);
		payload.put("targetEntityType", targetEntityType);
		payload.put("targetEntityName", targetEntityName);

		Map<String, Map<String, Object>> toUpload = new HashMap<>();
		toUpload.put(waypointId, payload);
		networkManager.sendWaypointsUpdate(ownerId, toUpload);

		if (target.targetEntity() != null) {
			String displayName = targetEntityName == null || targetEntityName.isBlank() ? "实体" : targetEntityName;
			client.field_1724.method_7353(class_2561.method_43470("§6[TV] 已报点实体: " + displayName + " @ " + markX + " " + markY + " " + markZ), true);
		} else {
			client.field_1724.method_7353(class_2561.method_43470("§6[TV] 已报点方块: " + markX + " " + markY + " " + markZ), true);
		}
	}

	private List<String> collectOverflowQuickWaypointIdsByOwner(UUID ownerId, String exceptWaypointId, int maxKeepCount) {
		List<Map.Entry<String, SharedWaypointInfo>> quickEntries = new java.util.ArrayList<>();
		for (Map.Entry<String, SharedWaypointInfo> entry : sharedWaypoints.entrySet()) {
			SharedWaypointInfo waypoint = entry.getValue();
			if (waypoint == null) {
				continue;
			}
			if (exceptWaypointId != null && exceptWaypointId.equals(entry.getKey())) {
				continue;
			}
			if (!ownerId.equals(waypoint.ownerId())) {
				continue;
			}
			if (!"quick".equalsIgnoreCase(waypoint.waypointKind())) {
				continue;
			}
			quickEntries.add(entry);
		}

		int normalizedMax = Math.max(1, maxKeepCount);
		int removeCount = quickEntries.size() - normalizedMax + 1;
		if (removeCount <= 0) {
			return List.of();
		}

		quickEntries.sort(Comparator.comparingLong(left -> left.getValue().createdAt()));
		List<String> overflowIds = new java.util.ArrayList<>();
		for (int index = 0; index < removeCount && index < quickEntries.size(); index++) {
			overflowIds.add(quickEntries.get(index).getKey());
		}
		return overflowIds;
	}

	private MarkTarget resolveMarkTarget(class_310 client) {
		if (client.field_1724 == null || client.field_1687 == null) {
			return null;
		}

		class_243 eyePos = client.field_1724.method_5836(1.0F);
		class_243 lookVec = client.field_1724.method_5828(1.0F).method_1029();
		double maxDistance = Math.max(config.getRenderDistance(), MARK_RAYCAST_DISTANCE);
		class_243 rayEnd = eyePos.method_1019(lookVec.method_1021(maxDistance));

		class_3965 blockHit = client.field_1687.method_17742(new class_3959(
			eyePos,
			rayEnd,
			class_3959.class_3960.field_17559,
			class_3959.class_242.field_1348,
			client.field_1724
		));

		double blockDistSq = Double.MAX_VALUE;
		class_243 blockMarkPos = null;
		if (blockHit != null && blockHit.method_17783() == class_239.class_240.field_1332) {
			blockDistSq = eyePos.method_1025(blockHit.method_17784());
			blockMarkPos = new class_243(
				blockHit.method_17777().method_10263() + 0.5D,
				blockHit.method_17777().method_10264() + 1.0D,
				blockHit.method_17777().method_10260() + 0.5D
			);
		}

		class_238 searchBox = client.field_1724.method_5829().method_18804(lookVec.method_1021(maxDistance)).method_1014(1.0D);
		class_3966 entityHit = class_1675.method_18075(
			client.field_1724,
			eyePos,
			rayEnd,
			searchBox,
			entity -> entity != null && entity.method_5805() && !entity.method_7325() && entity.method_5863(),
			maxDistance * maxDistance
		);

		double entityDistSq = Double.MAX_VALUE;
		class_1297 entityTarget = null;
		class_243 entityMarkPos = null;
		if (entityHit != null && entityHit.method_17782() != null) {
			entityTarget = entityHit.method_17782();
			entityMarkPos = entityTarget.method_19538();
			entityDistSq = eyePos.method_1025(entityHit.method_17784());
		}

		if (entityMarkPos == null && blockMarkPos == null) {
			return null;
		}
		if (entityMarkPos != null && entityDistSq <= blockDistSq) {
			return new MarkTarget(entityMarkPos, entityTarget);
		}
		return new MarkTarget(blockMarkPos, null);
	}

	private void renderSharedWaypointMarkers(WorldRenderContext context, class_243 cameraPos, boolean depthTestEnabled) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1687 == null) {
			return;
		}
		if (!config.isShowSharedWaypoints() || sharedWaypoints.isEmpty()) {
			return;
		}

		String currentDimension = client.field_1687.method_27983().method_29177().toString();
		double maxDistance = Math.max(config.getRenderDistance(), 16.0);

		for (SharedWaypointInfo waypoint : sharedWaypoints.values()) {
			if (waypoint == null) {
				continue;
			}
			if (waypoint.dimension() != null && !waypoint.dimension().isBlank() && !waypoint.dimension().equals(currentDimension)) {
				continue;
			}

			class_243 worldPos = resolveWaypointWorldPosition(client, waypoint, currentDimension);
			if (worldPos == null) {
				continue;
			}
			boolean isTmWaypoint = isTampermonkeyWaypoint(waypoint);
			if (!isTmWaypoint && client.field_1724.method_19538().method_1022(worldPos) > maxDistance) {
				continue;
			}

			int color = withAlpha(waypoint.color(), 0xCC);
			if (isTmWaypoint) {
				renderTampermonkeyWaypointStyle(context, waypoint, worldPos, cameraPos, color, depthTestEnabled);
				continue;
			}

			class_243 relativePos = worldPos.method_1020(cameraPos);
			renderWaypointMarkerStyle(context, relativePos, color, depthTestEnabled);
		}
	}

	private boolean isTampermonkeyWaypoint(SharedWaypointInfo waypoint) {
		if (waypoint == null) {
			return false;
		}

		String sourceType = waypoint.sourceType();
		if (sourceType != null && sourceType.equalsIgnoreCase("admin_tactical")) {
			return true;
		}

		String waypointKind = waypoint.waypointKind();
		return waypointKind != null && waypointKind.equalsIgnoreCase("admin_tactical");
	}

	private void renderTampermonkeyWaypointStyle(
		WorldRenderContext context,
		SharedWaypointInfo waypoint,
		class_243 resolvedWorldPos,
		class_243 cameraPos,
		int color,
		boolean depthTestEnabled
	) {
		class_310 client = class_310.method_1551();
		if (client.field_1687 == null) {
			return;
		}

		double renderX = resolvedWorldPos.field_1352;
		double renderZ = resolvedWorldPos.field_1350;
		double baseY = client.field_1687.method_31607();
		double beamHeight = config.getTampermonkeyBeamHeight();

		class_243 beamBaseRelative = new class_243(renderX - cameraPos.field_1352, baseY - cameraPos.field_1351, renderZ - cameraPos.field_1350);
		class_243 beamCenter = beamBaseRelative.method_1031(0.0D, 0.08D, 0.0D);
		UnifiedRenderModule.drawVerticalBeam(
			context.matrixStack(),
			beamCenter,
			beamHeight,
			config.getTampermonkeyBeamWidth(),
			withAlpha(color, 0x55),
			depthTestEnabled
		);

		class_243 planeCenter = new class_243(renderX - cameraPos.field_1352, baseY - cameraPos.field_1351 + 0.03D, renderZ - cameraPos.field_1350);
		UnifiedRenderModule.drawHorizontalPlane(
			context.matrixStack(),
			planeCenter,
			1.8D,
			withAlpha(color, 0x4C),
			depthTestEnabled
		);

		renderCircle(
			context,
			planeCenter,
			1.15D,
			withAlpha(color, 0xA6),
			24,
			depthTestEnabled
		);

		class_243 topCenter = beamCenter.method_1031(0.0D, beamHeight, 0.0D);
		renderCircle(
			context,
			topCenter,
			0.48D,
			withAlpha(color, 0x9A),
			18,
			depthTestEnabled
		);
	}

	private class_243 resolveWaypointWorldPosition(class_310 client, SharedWaypointInfo waypoint, String currentDimension) {
		if (waypoint == null) {
			return null;
		}

		String targetType = waypoint.targetType();
		String targetEntityId = waypoint.targetEntityId();
		if (!"entity".equalsIgnoreCase(targetType) || targetEntityId == null || targetEntityId.isBlank()) {
			return new class_243(waypoint.x() + 0.5D, waypoint.y(), waypoint.z() + 0.5D);
		}

		class_243 localEntityPos = resolveLocalEntityPosition(client, targetEntityId, currentDimension);
		if (localEntityPos != null) {
			trackedEntityWaypointLastPositions.put(waypoint.waypointId(), localEntityPos);
			return localEntityPos;
		}

		if (isPlayerTarget(waypoint)) {
			class_243 localPlayerPos = resolveLocalPlayerPositionFallback(client, targetEntityId, waypoint.targetEntityName(), currentDimension);
			if (localPlayerPos != null) {
				trackedEntityWaypointLastPositions.put(waypoint.waypointId(), localPlayerPos);
				return localPlayerPos;
			}
		}

		class_243 remoteEntityPos = networkManager == null ? null : networkManager.getRemoteEntityPosition(targetEntityId, currentDimension);
		if (remoteEntityPos != null) {
			trackedEntityWaypointLastPositions.put(waypoint.waypointId(), remoteEntityPos);
			return remoteEntityPos;
		}

		if (isPlayerTarget(waypoint) && networkManager != null) {
			class_243 remotePlayerPos = networkManager.getRemotePlayerPosition(targetEntityId, waypoint.targetEntityName(), currentDimension);
			if (remotePlayerPos != null) {
				trackedEntityWaypointLastPositions.put(waypoint.waypointId(), remotePlayerPos);
				return remotePlayerPos;
			}
		}

		class_243 lastKnown = trackedEntityWaypointLastPositions.get(waypoint.waypointId());
		if (lastKnown != null) {
			return lastKnown;
		}

		class_243 initial = new class_243(waypoint.x() + 0.5D, waypoint.y(), waypoint.z() + 0.5D);
		trackedEntityWaypointLastPositions.put(waypoint.waypointId(), initial);
		return initial;
	}

	private class_243 resolveLocalEntityPosition(class_310 client, String entityUuid, String currentDimension) {
		if (client == null || client.field_1687 == null || entityUuid == null || entityUuid.isBlank()) {
			return null;
		}

		String worldDimension = client.field_1687.method_27983().method_29177().toString();
		if (currentDimension != null && !currentDimension.isBlank() && !currentDimension.equals(worldDimension)) {
			return null;
		}

		try {
			UUID uuid = UUID.fromString(entityUuid);
			class_1297 cached = entityUuidCache.get(uuid);
			if (cached != null && cached.method_5805()) {
				return cached.method_19538();
			}
		} catch (IllegalArgumentException ignored) {
		}

		return null;
	}
	
	private void updateEntityCache(class_310 client) {
		if (client == null || client.field_1687 == null) {
			entityUuidCache.clear();
			lastCachedDimension = null;
			return;
		}
		
		String currentDimension = client.field_1687.method_27983().method_29177().toString();
		if (!currentDimension.equals(lastCachedDimension)) {
			entityUuidCache.clear();
			lastCachedDimension = currentDimension;
		}
		
		entityUuidCache.entrySet().removeIf(entry -> {
			class_1297 e = entry.getValue();
			return e == null || !e.method_5805();
		});
		
		for (class_1297 entity : client.field_1687.method_18112()) {
			if (entity != null && entity.method_5805()) {
				entityUuidCache.put(entity.method_5667(), entity);
			}
		}
	}

	private class_243 resolveLocalPlayerPositionFallback(class_310 client, String targetEntityId, String targetEntityName, String currentDimension) {
		if (client == null || client.field_1687 == null) {
			return null;
		}

		String worldDimension = client.field_1687.method_27983().method_29177().toString();
		if (currentDimension != null && !currentDimension.isBlank() && !currentDimension.equals(worldDimension)) {
			return null;
		}

		UUID expectedUuid = null;
		if (targetEntityId != null && !targetEntityId.isBlank()) {
			try {
				expectedUuid = UUID.fromString(targetEntityId);
			} catch (IllegalArgumentException ignored) {
			}
		}

		for (class_742 player : client.field_1687.method_18456()) {
			if (player == null) {
				continue;
			}
			if (expectedUuid != null && expectedUuid.equals(player.method_5667())) {
				return player.method_19538();
			}
			if (targetEntityName != null && !targetEntityName.isBlank()) {
				String currentName = player.method_5477().getString();
				if (currentName != null && currentName.equalsIgnoreCase(targetEntityName)) {
					return player.method_19538();
				}
			}
		}

		return null;
	}

	private boolean isPlayerTarget(SharedWaypointInfo waypoint) {
		if (waypoint == null) {
			return false;
		}
		String targetEntityType = waypoint.targetEntityType();
		return "minecraft:player".equalsIgnoreCase(targetEntityType);
	}

	private void renderWaypointMarkerStyle(WorldRenderContext context, class_243 basePos, int color, boolean depthTestEnabled) {
		String style = config.getWaypointUiStyle();
		if (Config.WAYPOINT_UI_RING.equals(style)) {
			renderWaypointRingStyle(context, basePos, color, depthTestEnabled);
			return;
		}
		if (Config.WAYPOINT_UI_PIN.equals(style)) {
			renderWaypointPinStyle(context, basePos, color, depthTestEnabled);
			return;
		}
		renderWaypointBeaconStyle(context, basePos, color, depthTestEnabled);
	}

	private void renderWaypointBeaconStyle(WorldRenderContext context, class_243 basePos, int color, boolean depthTestEnabled) {
		class_243 center = basePos.method_1031(0.0D, 0.1D, 0.0D);
		double beamHeight = config.getWaypointBeaconBeamHeight();
		double beamRadius = config.getWaypointBeaconBeamWidth();
		UnifiedRenderModule.drawVerticalBeam(context.matrixStack(), center, beamHeight, beamRadius, withAlpha(color, 0x66), depthTestEnabled);

		renderCircle(context, center.method_1031(0.0D, 0.02D, 0.0D), 0.75D, withAlpha(color, 0xB0), 18, depthTestEnabled);
		renderCircle(context, center.method_1031(0.0D, beamHeight, 0.0D), 0.42D, withAlpha(color, 0xA0), 14, depthTestEnabled);
	}

	private void renderWaypointRingStyle(WorldRenderContext context, class_243 basePos, int color, boolean depthTestEnabled) {
		class_243 center = basePos.method_1031(0.0D, 0.05D, 0.0D);
		renderCircle(context, center, 0.95D, color, 24, depthTestEnabled);
		renderCircle(context, center.method_1031(0.0D, 0.3D, 0.0D), 0.65D, withAlpha(color, 0x9A), 18, depthTestEnabled);

		for (int i = 0; i < 4; i++) {
			double angle = (Math.PI / 2.0D) * i;
			class_243 start = center.method_1031(Math.cos(angle) * 0.3D, 0.0D, Math.sin(angle) * 0.3D);
			class_243 end = center.method_1031(Math.cos(angle) * 1.2D, 0.0D, Math.sin(angle) * 1.2D);
			UnifiedRenderModule.drawLine(context.matrixStack(), start, end, withAlpha(color, 0x88), depthTestEnabled);
		}

		UnifiedRenderModule.drawLine(context.matrixStack(), center.method_1031(0.0D, 0.1D, 0.0D), center.method_1031(0.0D, 3.0D, 0.0D), withAlpha(color, 0xB5), depthTestEnabled);
	}

	private void renderWaypointPinStyle(WorldRenderContext context, class_243 basePos, int color, boolean depthTestEnabled) {
		class_243 center = basePos.method_1031(0.0D, 0.1D, 0.0D);
		class_243 head = basePos.method_1031(0.0D, 2.8D, 0.0D);
		UnifiedRenderModule.drawLine(context.matrixStack(), center, head, color, depthTestEnabled);

		double size = 0.42D;
		class_243 north = head.method_1031(0.0D, 0.0D, -size);
		class_243 south = head.method_1031(0.0D, 0.0D, size);
		class_243 east = head.method_1031(size, 0.0D, 0.0D);
		class_243 west = head.method_1031(-size, 0.0D, 0.0D);
		UnifiedRenderModule.drawLine(context.matrixStack(), north, south, color, depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), east, west, color, depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), north, east, withAlpha(color, 0x9A), depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), east, south, withAlpha(color, 0x9A), depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), south, west, withAlpha(color, 0x9A), depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), west, north, withAlpha(color, 0x9A), depthTestEnabled);

		renderCircle(context, center.method_1031(0.0D, 0.02D, 0.0D), 0.35D, withAlpha(color, 0xB0), 12, depthTestEnabled);
	}

	private void renderCircle(WorldRenderContext context, class_243 center, double radius, int color, int segments, boolean depthTestEnabled) {
		if (segments < 3) {
			return;
		}
		double step = (Math.PI * 2.0D) / segments;
		class_243 prev = null;
		for (int i = 0; i <= segments; i++) {
			double angle = step * i;
			class_243 current = new class_243(
				center.field_1352 + Math.cos(angle) * radius,
				center.field_1351,
				center.field_1350 + Math.sin(angle) * radius
			);
			if (prev != null) {
				UnifiedRenderModule.drawLine(context.matrixStack(), prev, current, color, depthTestEnabled);
			}
			prev = current;
		}
	}

	private int withAlpha(int rgb, int alpha) {
		return ((alpha & 0xFF) << 24) | (rgb & 0x00FFFFFF);
	}

	private record MarkTarget(class_243 position, class_1297 targetEntity) {
	}
	
	// 网络管理方法
	public static void reconnectToServer() {
		if (networkManager != null) {
			networkManager.disconnect();
			if (espEnabled) {
				networkManager.connect();
			}
		}
	}
	
	// Getter和Setter方法
	public static boolean isEspEnabled() {
		return espEnabled;
	}
	
	public static void setEspEnabled(boolean espEnabled) {
		StandaloneMultiPlayerESP.espEnabled = espEnabled;
	}
	
	
	public static Config getConfig() {
		return config;
	}
	
	public static Map<UUID, class_243> getPlayerPositions() {
		return playerPositions;
	}
	
	public static Map<UUID, class_243> getServerPlayerPositions() {
		return serverPlayerPositions;
	}
	
	public static PlayerESPNetworkManager getNetworkManager() {
		return networkManager;
	}
}
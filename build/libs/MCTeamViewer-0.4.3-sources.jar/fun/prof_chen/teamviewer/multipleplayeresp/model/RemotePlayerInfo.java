package fun.prof_chen.teamviewer.multipleplayeresp.model;

import java.util.UUID;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public record RemotePlayerInfo(UUID uuid, class_243 position, class_5321<class_1937> dimension, String name) {
	public static class_5321<class_1937> parseDimension(String dimensionId, class_5321<class_1937> fallback) {
		if (dimensionId == null || dimensionId.isBlank()) {
			return fallback;
		}

		class_2960 parsed = class_2960.method_12829(dimensionId);
		if (parsed == null) {
			return fallback;
		}

		return class_5321.method_29179(class_7924.field_41223, parsed);
	}
}
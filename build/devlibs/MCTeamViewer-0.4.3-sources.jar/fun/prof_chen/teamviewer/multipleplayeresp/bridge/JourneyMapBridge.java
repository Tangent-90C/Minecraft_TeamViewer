package fun.prof_chen.teamviewer.multipleplayeresp.bridge;

import journeymap.api.v2.client.IClientAPI;
import journeymap.api.v2.client.IClientPlugin;
import journeymap.api.v2.client.JourneyMapPlugin;
import journeymap.api.v2.common.waypoint.Waypoint;
import journeymap.api.v2.common.waypoint.WaypointFactory;
import journeymap.api.v2.common.waypoint.WaypointGroup;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import fun.prof_chen.teamviewer.multipleplayeresp.model.RemotePlayerInfo;
import fun.prof_chen.teamviewer.multipleplayeresp.model.SharedWaypointInfo;
import fun.prof_chen.teamviewer.multipleplayeresp.model.ReportDataSchemas.WaypointDataPayload;
import fun.prof_chen.teamviewer.multipleplayeresp.network.PlayerESPNetworkManager;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@JourneyMapPlugin(apiVersion = "2.0.0")
public final class JourneyMapBridge implements IClientPlugin {
    private static final Logger LOGGER = LoggerFactory.getLogger(JourneyMapBridge.class);
    private static final String MOD_ID = "teamviewer";
    private static final String SHARED_PREFIX = "[TV] ";
    private static final long UPDATE_INTERVAL_MS = 200L;
    private static final long LOCAL_SCAN_INTERVAL_MS = 1500L;

    private static volatile IClientAPI clientAPI;
    private static volatile boolean available = false;
    private static volatile boolean checked = false;
    private static volatile boolean tempGroupFindAttempted = false;
    private static volatile Map<UUID, RemotePlayerInfo> remotePlayers = Collections.emptyMap();
    private static volatile Map<String, SharedWaypointInfo> remoteWaypoints = Collections.emptyMap();
    private static volatile boolean espEnabled = false;
    private static volatile long lastUpdateMs = 0L;
    private static volatile long lastLocalScanMs = 0L;

    private static final Map<String, Waypoint> createdWaypoints = new ConcurrentHashMap<>();
    private static final Map<String, Vec3d> trackedEntityLastPositions = new ConcurrentHashMap<>();
    private static volatile WaypointGroup tempGroup;
    
    private static final Map<String, SharedWaypointInfo> knownLocalWaypoints = new ConcurrentHashMap<>();
    private static volatile PlayerESPNetworkManager networkManager;

    private static JourneyMapBridge INSTANCE;

    public JourneyMapBridge() {
        INSTANCE = this;
    }

    public static JourneyMapBridge getInstance() {
        return INSTANCE;
    }
    
    public static void setNetworkManager(PlayerESPNetworkManager manager) {
        networkManager = manager;
    }

    @Override
    public void initialize(IClientAPI jmClientApi) {
        clientAPI = jmClientApi;
        available = true;
        LOGGER.info("JourneyMap bridge initialized successfully via IClientPlugin");
    }

    @Override
    public String getModId() {
        return MOD_ID;
    }

    private void findTempGroup() {
        if (clientAPI == null) {
            return;
        }
        
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.world == null || mc.player == null) {
            return;
        }
        
        try {
            List<? extends WaypointGroup> allGroups = clientAPI.getAllWaypointGroups();
            if (allGroups != null) {
                for (WaypointGroup group : allGroups) {
                    String name = group.getName();
                    String guid = group.getGuid();
                    LOGGER.info("Found JourneyMap group: name='{}', guid='{}', modId='{}'", 
                        name, guid, group.getModId());
                    
                    if (name != null && (name.toLowerCase().contains("temp") || 
                        guid != null && guid.toLowerCase().contains("temp"))) {
                        tempGroup = group;
                        LOGGER.info("Using JourneyMap temp group: {} ({})", name, guid);
                        break;
                    }
                }
            }
            
            if (tempGroup == null) {
                LOGGER.info("No temp group found, waypoints will use default group");
            }
            tempGroupFindAttempted = true;
        } catch (Exception e) {
            LOGGER.error("Failed to find temp group: {}", e.getMessage(), e);
        }
    }

    public static void tick(PlayerESPNetworkManager networkManagerSource,
                            Map<UUID, RemotePlayerInfo> remotePlayersSource,
                            Map<String, SharedWaypointInfo> waypointsSource, boolean enabled) {
        if (networkManagerSource != null) {
            networkManager = networkManagerSource;
        }
        if (remotePlayersSource != null) {
            remotePlayers = remotePlayersSource.isEmpty() ? Collections.emptyMap() : Map.copyOf(remotePlayersSource);
        }
        if (waypointsSource != null) {
            remoteWaypoints = waypointsSource.isEmpty() ? Collections.emptyMap() : Map.copyOf(waypointsSource);
        }
        espEnabled = enabled;

        if (!FabricLoader.getInstance().isModLoaded("journeymap")) {
            return;
        }

        if (!checked) {
            checked = true;
            if (clientAPI == null) {
                LOGGER.warn("JourneyMap ClientAPI not yet initialized (plugin not loaded)");
            }
        }

        if (!available || clientAPI == null) {
            return;
        }

        if (tempGroup == null && !tempGroupFindAttempted) {
            INSTANCE.findTempGroup();
        }

        long now = System.currentTimeMillis();
        if (now - lastUpdateMs < UPDATE_INTERVAL_MS) {
            return;
        }
        lastUpdateMs = now;

        try {
            updateWaypoints();
            
            if (now - lastLocalScanMs >= LOCAL_SCAN_INTERVAL_MS) {
                lastLocalScanMs = now;
                scanAndSyncLocalWaypoints();
            }
        } catch (Exception e) {
            LOGGER.error("Failed to update JourneyMap waypoints: {}", e.getMessage(), e);
        }
    }

    private static void scanAndSyncLocalWaypoints() {
        if (clientAPI == null || networkManager == null) {
            return;
        }
        
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.world == null) {
            return;
        }
        
        if (!networkManager.isConnected()) {
            return;
        }
        
        try {
            UUID ownerId = client.player.getUuid();
            String ownerName = client.player.getName().getString();
            String dimension = client.world.getRegistryKey().getValue().toString();
            
            Map<String, SharedWaypointInfo> currentLocal = new HashMap<>();
            
            List<? extends Waypoint> allWaypoints = clientAPI.getAllWaypoints();
            if (allWaypoints != null) {
                for (Waypoint wp : allWaypoints) {
                    String name = wp.getName();
                    if (name == null || name.isBlank() || name.startsWith(SHARED_PREFIX)) {
                        continue;
                    }
                    
                    String wpModId = wp.getModId();
                    if (wpModId != null && wpModId.equals(MOD_ID)) {
                        continue;
                    }
                    
                    BlockPos pos = wp.getBlockPos();
                    String dimStr = dimension;
                    
                    long createdAt = System.currentTimeMillis();
                    String idSource = ownerId + "|" + createdAt + "|" + dimStr + "|" + pos.getX() + "|" + pos.getY() + "|" + pos.getZ();
                    String waypointId = UUID.nameUUIDFromBytes(idSource.getBytes(StandardCharsets.UTF_8)).toString();
                    
                    SharedWaypointInfo info = new SharedWaypointInfo(
                        waypointId,
                        ownerId,
                        ownerName,
                        name,
                        String.valueOf(name.charAt(0)).toUpperCase(),
                        pos.getX(),
                        pos.getY(),
                        pos.getZ(),
                        dimStr,
                        wp.getColor(),
                        createdAt,
                        null,
                        null,
                        null,
                        null,
                        "manual",
                        null,
                        "journeymap"
                    );
                    
                    currentLocal.put(waypointId, info);
                }
            }
            
            Map<String, Map<String, Object>> toUpload = new HashMap<>();
            for (Map.Entry<String, SharedWaypointInfo> entry : currentLocal.entrySet()) {
                if (!knownLocalWaypoints.containsKey(entry.getKey())) {
                    SharedWaypointInfo info = entry.getValue();
                    WaypointDataPayload payload = new WaypointDataPayload(
                        info.x(), info.y(), info.z(),
                        info.dimension(),
                        info.name(),
                        info.symbol(),
                        info.color(),
                        info.ownerId().toString(),
                        info.ownerName(),
                        info.createdAt(),
                        (Integer) null,
                        "manual",
                        (Boolean) null,
                        (Integer) null,
                        (String) null,
                        (String) null,
                        (String) null,
                        (String) null,
                        (String) null,
                        (Boolean) null,
                        (String) null,
                        "journeymap"
                    );
                    toUpload.put(entry.getKey(), payload.toMap());
                    knownLocalWaypoints.put(entry.getKey(), info);
                    LOGGER.info("Uploading new JourneyMap waypoint: {} at ({}, {}, {})", 
                        info.name(), info.x(), info.y(), info.z());
                }
            }
            
            List<String> toDelete = new ArrayList<>();
            for (String knownId : knownLocalWaypoints.keySet()) {
                if (!currentLocal.containsKey(knownId)) {
                    toDelete.add(knownId);
                }
            }
            
            for (String deleteId : toDelete) {
                knownLocalWaypoints.remove(deleteId);
                LOGGER.info("JourneyMap waypoint deleted: {}", deleteId);
            }
            
            if (!toUpload.isEmpty() && networkManager.isConnected()) {
                networkManager.sendWaypointsUpdate(ownerId, toUpload);
            }
            
            if (!toDelete.isEmpty() && networkManager.isConnected()) {
                networkManager.sendWaypointsDelete(ownerId, toDelete);
            }
            
        } catch (Exception e) {
            LOGGER.error("Failed to scan JourneyMap waypoints: {}", e.getMessage(), e);
        }
    }

    private static void updateWaypoints() {
        if (!espEnabled) {
            clearAllWaypoints();
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        UUID localPlayerId = client.player.getUuid();
        RegistryKey<World> currentDimension = client.world.getRegistryKey();
        String currentDimensionStr = currentDimension.getValue().toString();

        Set<String> activeWaypointIds = new HashSet<>();

        for (Map.Entry<UUID, RemotePlayerInfo> entry : remotePlayers.entrySet()) {
            RemotePlayerInfo info = entry.getValue();
            if (info == null || info.uuid().equals(localPlayerId)) {
                continue;
            }
            if (info.dimension() != null && !currentDimension.equals(info.dimension())) {
                continue;
            }

            String waypointId = "player_" + info.uuid();
            activeWaypointIds.add(waypointId);

            String name = SHARED_PREFIX + (info.name() != null ? info.name() : "Player");

            Vec3d pos = info.position();
            int x = (int) Math.floor(pos.x);
            int y = (int) Math.floor(pos.y);
            int z = (int) Math.floor(pos.z);

            updateOrCreateWaypoint(waypointId, name, x, y, z, currentDimension, 0xFF5555);
        }

        for (Map.Entry<String, SharedWaypointInfo> entry : remoteWaypoints.entrySet()) {
            SharedWaypointInfo wp = entry.getValue();
            if (wp == null) {
                continue;
            }

            RegistryKey<World> wpDimension = parseDimension(wp.dimension());
            if (wpDimension != null && !currentDimension.equals(wpDimension)) {
                continue;
            }

            String waypointId = "shared_" + wp.waypointId();
            activeWaypointIds.add(waypointId);

            String ownerName = wp.ownerName() != null ? wp.ownerName() : "Unknown";
            String wpName = SHARED_PREFIX + ownerName + ": " + (wp.name() != null ? wp.name() : "WP");

            Vec3d trackedPos = resolveWaypointSyncPosition(wp, currentDimensionStr);
            int x = (int) Math.floor(trackedPos.x);
            int y = (int) Math.floor(trackedPos.y);
            int z = (int) Math.floor(trackedPos.z);

            updateOrCreateWaypoint(waypointId, wpName, x, y, z,
                    wpDimension != null ? wpDimension : currentDimension, wp.color());
        }

        List<String> toRemove = new ArrayList<>();
        for (String existingId : createdWaypoints.keySet()) {
            if (!activeWaypointIds.contains(existingId)) {
                toRemove.add(existingId);
            }
        }
        for (String id : toRemove) {
            removeWaypoint(id);
        }
    }

    private static Vec3d resolveWaypointSyncPosition(SharedWaypointInfo waypoint, String currentDimension) {
        if (waypoint == null) {
            return Vec3d.ZERO;
        }

        String targetType = waypoint.targetType();
        String targetEntityId = waypoint.targetEntityId();

        if (!"entity".equalsIgnoreCase(targetType) || targetEntityId == null || targetEntityId.isBlank()) {
            return new Vec3d(waypoint.x() + 0.5D, waypoint.y(), waypoint.z() + 0.5D);
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null) {
            String worldDimension = client.world.getRegistryKey().getValue().toString();
            if (Objects.equals(currentDimension, worldDimension)) {
                try {
                    UUID targetUuid = UUID.fromString(targetEntityId);
                    for (Entity entity : client.world.getEntities()) {
                        if (entity != null && entity.getUuid().equals(targetUuid)) {
                            Vec3d pos = entity.getPos();
                            trackedEntityLastPositions.put(waypoint.waypointId(), pos);
                            return pos;
                        }
                    }
                } catch (IllegalArgumentException ignored) {
                }

                if (isPlayerTarget(waypoint)) {
                    Vec3d playerPos = resolveLocalPlayerPositionFallback(client, targetEntityId, waypoint.targetEntityName());
                    if (playerPos != null) {
                        trackedEntityLastPositions.put(waypoint.waypointId(), playerPos);
                        return playerPos;
                    }
                }
            }
        }

        Vec3d lastKnown = trackedEntityLastPositions.get(waypoint.waypointId());
        if (lastKnown != null) {
            return lastKnown;
        }

        Vec3d initial = new Vec3d(waypoint.x() + 0.5D, waypoint.y(), waypoint.z() + 0.5D);
        trackedEntityLastPositions.put(waypoint.waypointId(), initial);
        return initial;
    }

    private static Vec3d resolveLocalPlayerPositionFallback(MinecraftClient client, String targetEntityId, String targetEntityName) {
        if (client == null || client.world == null) {
            return null;
        }

        UUID expectedUuid = null;
        if (targetEntityId != null && !targetEntityId.isBlank()) {
            try {
                expectedUuid = UUID.fromString(targetEntityId);
            } catch (IllegalArgumentException ignored) {
            }
        }

        for (var player : client.world.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (expectedUuid != null && expectedUuid.equals(player.getUuid())) {
                return player.getPos();
            }
            if (targetEntityName != null && !targetEntityName.isBlank()) {
                String currentName = player.getName().getString();
                if (currentName != null && currentName.equalsIgnoreCase(targetEntityName)) {
                    return player.getPos();
                }
            }
        }

        return null;
    }

    private static boolean isPlayerTarget(SharedWaypointInfo waypoint) {
        if (waypoint == null) {
            return false;
        }
        String targetEntityType = waypoint.targetEntityType();
        return targetEntityType != null && "minecraft:player".equalsIgnoreCase(targetEntityType);
    }

    private static void updateOrCreateWaypoint(String id, String name, int x, int y, int z,
                                               RegistryKey<World> dimension, int color) {
        try {
            Waypoint existing = createdWaypoints.get(id);
            if (existing != null) {
                BlockPos existingPos = existing.getBlockPos();
                boolean positionChanged = existingPos.getX() != x || existingPos.getY() != y || existingPos.getZ() != z;
                if (!positionChanged) {
                    return;
                }
                existing.setPos(x, y, z);
                LOGGER.debug("Updated JourneyMap waypoint position: {} to ({}, {}, {})", name, x, y, z);
                return;
            }

            Waypoint waypoint = createWaypoint(name, x, y, z, dimension, color);
            if (waypoint != null) {
                createdWaypoints.put(id, waypoint);
                LOGGER.info("Created JourneyMap waypoint: {} at ({}, {}, {}) groupId={}", 
                    name, x, y, z, waypoint.getGroupId());
            }
        } catch (Exception e) {
            LOGGER.error("Failed to create JourneyMap waypoint: {}", e.getMessage(), e);
        }
    }

    private static Waypoint createWaypoint(String name, int x, int y, int z, RegistryKey<World> dimension, int color) {
        try {
            BlockPos pos = new BlockPos(x, y, z);

            Waypoint waypoint = WaypointFactory.createClientWaypoint(MOD_ID, pos, name, dimension, false);

            if (waypoint == null) {
                LOGGER.warn("WaypointFactory.createClientWaypoint returned null");
                return null;
            }

            waypoint.setColor(color);
            waypoint.setEnabled(true);
            waypoint.setPersistent(false);

            if (tempGroup != null) {
                boolean added = tempGroup.addWaypoint(waypoint);
                LOGGER.debug("Added waypoint to temp group: {}, result: {}", name, added);
            }

            clientAPI.addWaypoint(MOD_ID, waypoint);

            LOGGER.debug("Created JourneyMap waypoint via API: {} at ({}, {}, {}) in {}", name, x, y, z, dimension.getValue());
            return waypoint;
        } catch (Exception e) {
            LOGGER.error("Failed to create JourneyMap waypoint via API: {}", e.getMessage(), e);
            return null;
        }
    }

    private static RegistryKey<World> parseDimension(String dimension) {
        if (dimension == null || dimension.isBlank()) {
            return null;
        }

        try {
            Identifier dimLocation;
            if (dimension.contains(":")) {
                dimLocation = Identifier.of(dimension);
            } else {
                dimLocation = Identifier.of("minecraft:" + dimension.replace("minecraft:", ""));
            }

            if (dimLocation.equals(World.OVERWORLD.getValue())) {
                return World.OVERWORLD;
            } else if (dimLocation.equals(World.NETHER.getValue())) {
                return World.NETHER;
            } else if (dimLocation.equals(World.END.getValue())) {
                return World.END;
            }

            return RegistryKey.of(RegistryKeys.WORLD, dimLocation);
        } catch (Exception e) {
            LOGGER.warn("Failed to parse dimension: {}", dimension);
            return null;
        }
    }

    private static void removeWaypoint(String id) {
        Waypoint waypoint = createdWaypoints.remove(id);
        if (waypoint == null) {
            return;
        }

        try {
            clientAPI.removeWaypoint(MOD_ID, waypoint);
            LOGGER.debug("Removed JourneyMap waypoint: {}", id);
        } catch (Exception e) {
            LOGGER.error("Failed to remove JourneyMap waypoint: {}", e.getMessage(), e);
        }
    }

    private static void clearAllWaypoints() {
        for (String id : new ArrayList<>(createdWaypoints.keySet())) {
            removeWaypoint(id);
        }
        trackedEntityLastPositions.clear();
    }

    public static void reset() {
        clearAllWaypoints();
        remotePlayers = Collections.emptyMap();
        remoteWaypoints = Collections.emptyMap();
        knownLocalWaypoints.clear();
    }

    public static boolean isAvailable() {
        return available && clientAPI != null;
    }
}

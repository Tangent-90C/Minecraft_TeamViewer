package fun.prof_chen.teamviewer.multipleplayeresp.core;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import fun.prof_chen.teamviewer.multipleplayeresp.bridge.XaeroWaypointShareBridge;
import fun.prof_chen.teamviewer.multipleplayeresp.bridge.XaeroWorldMapBridge;
import fun.prof_chen.teamviewer.multipleplayeresp.bridge.JourneyMapBridge;
import fun.prof_chen.teamviewer.multipleplayeresp.config.Config;
import fun.prof_chen.teamviewer.multipleplayeresp.model.RemotePlayerInfo;
import fun.prof_chen.teamviewer.multipleplayeresp.model.ReportDataSchemas;
import fun.prof_chen.teamviewer.multipleplayeresp.model.SharedWaypointInfo;
import fun.prof_chen.teamviewer.multipleplayeresp.network.PlayerESPNetworkManager;
import fun.prof_chen.teamviewer.multipleplayeresp.ui.PlayerESPConfigScreen;
import fun.prof_chen.teamviewer.multipleplayeresp.render.UnifiedRenderModule;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class StandaloneMultiPlayerESP implements ClientModInitializer {
	public static final String MOD_ID = "multipleplayeresp";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	
	public static final MinecraftClient MC = MinecraftClient.getInstance();
	
	// Mod keybinding
	private static KeyBinding toggleKey;
	private static KeyBinding configKey;
	private static KeyBinding markKey;
	
	// Player position tracking
	private static final Map<UUID, Vec3d> playerPositions = new ConcurrentHashMap<>();
	private static final Map<UUID, RemotePlayerInfo> remotePlayers = new ConcurrentHashMap<>();
	private static final Map<UUID, Vec3d> serverPlayerPositions = new ConcurrentHashMap<>();
	private static final Map<String, SharedWaypointInfo> sharedWaypoints = new ConcurrentHashMap<>();
	private static final Map<String, Vec3d> trackedEntityWaypointLastPositions = new ConcurrentHashMap<>();
	
	// Performance optimization: entity UUID -> position cache (updated each tick)
	private static final Map<UUID, Entity> entityUuidCache = new ConcurrentHashMap<>();
	private static String lastCachedDimension = null;
	
	// Network manager
	private static PlayerESPNetworkManager networkManager;
	
	// Config
	private static Config config;
	
	// ESP settings
	private static boolean espEnabled = false;
	private static final boolean useServerPositions = false;

    // 用于控制位置更新频率
	private static int tickCounter = 0;

	// 鼠标中键双击报点
	private static final long MARK_DOUBLE_CLICK_MS = 300L;
	private static final double MARK_RAYCAST_DISTANCE = 256.0D;
	private static final double MARK_CANCEL_BASE_RADIUS = 1.2D;
	private static final double MARK_CANCEL_RADIUS_PER_BLOCK = 0.02D;
	private static final double MARK_CANCEL_MAX_RADIUS = 4.0D;
	private static final int MARKER_COLOR_RGB = 0xFF8C00;
	private static boolean middlePressedLastTick = false;
	private static long lastMiddleClickTs = 0L;
	
	@Override
	public void onInitializeClient() {
		// 初始化客户端功能
		LOGGER.info("Initializing MultiPlayer ESP mod");
		
		// 加载配置
		config = Config.load();
		
		// 初始化网络管理器
		networkManager = new PlayerESPNetworkManager(playerPositions, remotePlayers);
		PlayerESPNetworkManager.setConfig(config);
		registerWaypointSyncListener();
		
		// 注册按键绑定
		toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.multipleplayeresp.toggle",
			InputUtil.Type.KEYSYM,
			GLFW.GLFW_KEY_UNKNOWN, // 默认不绑定，玩家自行设置
			"category.multipleplayeresp.general"
		));
		
		// 注册配置界面按键
		configKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.multipleplayeresp.config",
			InputUtil.Type.KEYSYM,
			GLFW.GLFW_KEY_O, // 默认绑定O键
			"category.multipleplayeresp.general"
		));

		// 注册报点按键（可在游戏控制设置中自定义）
		markKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.multipleplayeresp.mark",
			InputUtil.Type.KEYSYM,
			GLFW.GLFW_KEY_UNKNOWN, // 默认不绑定，玩家自行设置
			"category.multipleplayeresp.general"
		));
		
		// 注册客户端tick事件
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			// 先消费网络线程投递的任务：保证网络状态与共享缓存在主线程串行更新，
			// 再执行本 tick 的输入处理、世界采集与上行发送，避免并发读写冲突。
			if (networkManager != null) {
				networkManager.pumpMainThreadTasks();
			}

			// 处理按键输入
			while (toggleKey.wasPressed()) {
				toggleESP();
			}
			
			// 处理配置界面按键
			while (configKey.wasPressed()) {
				openConfigScreen();
			}

			// 处理报点按键（单击触发）
			while (markKey.wasPressed()) {
				if (canCreateMark(client)) {
					createAndSyncQuickMark(client);
				}
			}
			
			// 更新玩家位置信息
			updatePlayerPositions();
			updateEntityCache(client);
			handleMiddleMouseDoubleClickMarking(client);
			handleAutoCancelWaypointOnEntityDeath(client);

			// 同步远程玩家到Xaero世界地图
			XaeroWorldMapBridge.tick(resolvePlayersForWorldMapBridge(), espEnabled);
			XaeroWaypointShareBridge.tick(networkManager, espEnabled, config);
			
			// 同步到JourneyMap
			JourneyMapBridge.tick(networkManager, resolvePlayersForWorldMapBridge(), sharedWaypoints, espEnabled);
			
			// 发送玩家位置到服务器
			if (espEnabled && networkManager != null) {
				handleRegistrationAndPositionUpdates();
			}
		});
		
		// 注册世界渲染事件
		WorldRenderEvents.AFTER_ENTITIES.register(context -> {
			if (espEnabled) {
				renderESP(context);
			}
		});
		
		LOGGER.info("MultiPlayer ESP mod initialized");
	}
	
	private void toggleESP() {
		espEnabled = !espEnabled;
		
		if (espEnabled) {
			// 启用ESP，连接到服务器
			networkManager.connect();
			LOGGER.info("MultiPlayer ESP enabled");
		} else {
			// 禁用ESP，断开连接
			networkManager.disconnect();
			sharedWaypoints.clear();
			trackedEntityWaypointLastPositions.clear();
			JourneyMapBridge.reset();
			LOGGER.info("MultiPlayer ESP disabled");
		}
		
		// 重置计数器
		tickCounter = 0;
	}
	
	private void openConfigScreen() {
		MC.setScreen(new PlayerESPConfigScreen(MC.currentScreen));
	}
	
	private Map<UUID, Map<String, Object>> collectPlayerData(MinecraftClient client) {
		Map<UUID, Map<String, Object>> players = new HashMap<>();
		if (client.world != null) {
			for (AbstractClientPlayerEntity p : client.world.getPlayers()) {
				UUID pid = p.getUuid();
				Vec3d pos = p.getPos();
				Vec3d vel = p.getVelocity();
				boolean isRiding = isPlayerRiding(p);
				ReportDataSchemas.PlayerDataPayload payload = new ReportDataSchemas.PlayerDataPayload(
						pos.x,
						pos.y,
						pos.z,
						vel.x,
						vel.y,
						vel.z,
						p.getWorld().getRegistryKey().getValue().toString(),
						p.getName().getString(),
						pid.toString(),
						p.getHealth(),
						p.getMaxHealth(),
						0,
						isRiding,
						p.getWidth(),
						p.getHeight());
				players.put(pid, payload.toMap());
			}
		}
		return players;
	}

	private boolean isPlayerRiding(AbstractClientPlayerEntity player) {
		if (player == null) {
			return false;
		}
		Entity vehicle = player.getVehicle();
		if (vehicle == null || vehicle.getType() == null) {
			return false;
		}
		String entityTypeText = String.valueOf(vehicle.getType()).toLowerCase(Locale.ROOT);
		return entityTypeText.contains("horse");
	}
	
	private Map<String, Map<String, Object>> collectEntityData(MinecraftClient client) {
		Map<String, Map<String, Object>> entities = new HashMap<>();
		if (client.world != null) {
			for (Entity entity : client.world.getEntities()) {
				if (entity == client.player) continue;
				String entityId = entity.getUuid().toString();
				Vec3d ePos = entity.getPos();
				Vec3d eVel = entity.getVelocity();
				String eDim = entity.getWorld().getRegistryKey().getValue().toString();
				String entityType = entity.getType().toString();
				ReportDataSchemas.EntityDataPayload payload = new ReportDataSchemas.EntityDataPayload(
						ePos.x,
						ePos.y,
						ePos.z,
						eVel.x,
						eVel.y,
						eVel.z,
						eDim,
						entityType,
						entity.hasCustomName() ? entity.getDisplayName().getString() : null,
						entity.getWidth(),
						entity.getHeight());
				entities.put(entityId, payload.toMap());
			}
		}
		return entities;
	}
	
	private void updatePlayerPositions() {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.world != null && client.player != null) {
			// 更新服务器端玩家位置
			serverPlayerPositions.clear();
			for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
				if (player != client.player) { // 不包括自己
					serverPlayerPositions.put(player.getUuid(), player.getPos());
				}
			}
		}
	}
	
	private void handleRegistrationAndPositionUpdates() {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || !client.player.isAlive()) {
			return;
		}
		
		tickCounter++;
		
		// 连接成功后按间隔发送玩家更新与实体更新（submitPlayerId 为本地玩家 UUID）
		int targetInterval = networkManager.isConnected()
				? networkManager.getNegotiatedReportIntervalTicks()
				: config.getUpdateInterval();
		if (networkManager.isConnected() && tickCounter >= Math.max(1, targetInterval)) {
			tickCounter = 0;
			UUID submitPlayerId = client.player.getUuid();
			networkManager.sendTabPlayersUpdate(submitPlayerId, collectTabPlayers(client));

			// 批量收集所有玩家（含本地）并上传
			Map<UUID, Map<String, Object>> players = collectPlayerData(client);
			networkManager.sendPlayersUpdate(submitPlayerId, players);

			// 收集并上报当前世界中的实体（带 submitPlayerId）
			if (config.isUploadEntities() && client.world != null) {
				Map<String, Map<String, Object>> entities = collectEntityData(client);
				networkManager.sendEntitiesUpdate(submitPlayerId, entities);
			}
		}
	}

	private List<Map<String, Object>> collectTabPlayers(MinecraftClient client) {
		List<Map<String, Object>> result = new ArrayList<>();
		if (client == null) return result;

		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (handler == null) return result;

		try {
			Collection<PlayerListEntry> entries = handler.getPlayerList();
			for (PlayerListEntry entry : entries) {
				if (entry == null || entry.getProfile() == null) continue;

				String playerId = entry.getProfile().getId() == null
						? null
						: entry.getProfile().getId().toString();

				String profileName = entry.getProfile().getName();
				if (profileName == null || profileName.isBlank()) continue;

				Team team = resolvePlayerTeam(client, entry, profileName);

				String prefixText = null;
				String prefixColored = null;

				if (team != null) {
					prefixText = team.getName();
					prefixColored = team.getPrefix().toString();
				}

				Map<String, Object> node = new HashMap<>();

				if (playerId != null && !playerId.isBlank()) {
					node.put("playerUUID", playerId);
				}

				node.put("name", profileName);

				if (prefixText != null && !prefixText.isBlank()) {
					node.put("prefixText", prefixText);
				}

				if (prefixColored != null && !prefixColored.isBlank()) {
					node.put("prefixColored", prefixColored);
				}

				result.add(node);
			}
		} catch (Exception e) {
			LOGGER.debug("collectTabPlayers failed: {}", e.getMessage());
		}

		return result;
	}

	private Team resolvePlayerTeam(MinecraftClient client,
								   PlayerListEntry entry,
								   String profileName) {

		// 1. 先用 PlayerListEntry 自带的（最准确）
		Team team = entry.getScoreboardTeam();
		if (team != null) return team;

		// 2. fallback 到客户端 scoreboard
		if (client != null && client.world != null) {
			Scoreboard scoreboard = client.world.getScoreboard();
			if (scoreboard != null) {
				return scoreboard.getScoreHolderTeam(profileName);
			}
		}

		return null;
	}

	private void renderESP(WorldRenderContext context) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.world == null) return;
		boolean depthTestEnabled = !config.isXrayMarkersAndBoxes();
		
		Vec3d cameraPos = context.camera().getPos();
		Map<UUID, Vec3d> positions = useServerPositions ? serverPlayerPositions : resolvePlayersForRender();
		
		// 渲染玩家位置框
		for (Map.Entry<UUID, Vec3d> entry : positions.entrySet()) {
			if (entry.getKey().equals(client.player.getUuid())) {
				continue; // 跳过自己
			}

			String markedTeam = networkManager == null ? null : networkManager.getPlayerMarkTeam(entry.getKey());
			int boxRenderColor = resolveRenderColorByTeam(markedTeam, config.getBoxColor());
			int tracerRenderColor = resolveRenderColorByTeam(markedTeam, config.getLineColor());

			Vec3d playerPos = entry.getValue();
			
			// 检查距离
			if (client.player.getPos().distanceTo(playerPos) <= config.getRenderDistance()) {
				// 计算相对位置
				Vec3d relativePos = playerPos.subtract(cameraPos);
				
				// 创建玩家包围盒
				Box box = new Box(
					relativePos.x - 0.3, relativePos.y, relativePos.z - 0.3,
					relativePos.x + 0.3, relativePos.y + 1.8, relativePos.z + 0.3
				);
				
				// 绘制包围盒
				if (config.isShowBoxes()) {
					UnifiedRenderModule.drawOutlinedBox(context.matrixStack(), box, boxRenderColor, depthTestEnabled);
				}
				
				// 绘制连线
				if (config.isShowLines()) {
					Vec3d targetPos = relativePos.add(0, 1.0, 0);
					Vec3d lookVec = client.player.getRotationVec(1.0F).normalize();
					Vec3d worldUp = new Vec3d(0, 1, 0);
					Vec3d rightVec = lookVec.crossProduct(worldUp);
					if (rightVec.lengthSquared() < 1.0E-6) {
						rightVec = new Vec3d(1, 0, 0);
					}
					Vec3d cameraUpVec = rightVec.normalize().crossProduct(lookVec).normalize();

					Vec3d tracerStart;
					if (config.isTracerStartTop()) {
						tracerStart = lookVec.multiply(0.6).add(cameraUpVec.multiply(config.getTracerTopOffset()));
					} else {
						tracerStart = lookVec.multiply(0.6);
					}
					UnifiedRenderModule.drawTracerLine(context.matrixStack(), tracerStart, targetPos, tracerRenderColor, depthTestEnabled);
				}
			}
		}

		renderSharedWaypointMarkers(context, cameraPos, depthTestEnabled);
	}

	private Map<UUID, Vec3d> resolvePlayersForRender() {
		if (config == null || !config.isPreferLocalDataForEsp()) {
			return playerPositions;
		}

		Map<UUID, Vec3d> mergedPositions = new HashMap<>(playerPositions);
		mergedPositions.putAll(serverPlayerPositions);
		return mergedPositions;
	}

	private Map<UUID, RemotePlayerInfo> resolvePlayersForWorldMapBridge() {
		if (config == null || !config.isPreferLocalDataForEsp()) {
			return remotePlayers;
		}

		Map<UUID, RemotePlayerInfo> mergedPlayers = new HashMap<>(remotePlayers);
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.world != null) {
			for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
				if (player == null || player == client.player) {
					continue;
				}
				RemotePlayerInfo localInfo = new RemotePlayerInfo(
					player.getUuid(),
					player.getPos(),
					player.getWorld().getRegistryKey(),
					player.getName().getString()
				);
				mergedPlayers.put(player.getUuid(), localInfo);
			}
		}

		return mergedPlayers;
	}

	private int resolveRenderColorByTeam(String teamTag, int fallbackColor) {
		if (teamTag == null || teamTag.isBlank()) {
			return fallbackColor;
		}

		String normalized = teamTag.trim().toLowerCase();
		if ("friendly".equals(normalized) || "friend".equals(normalized) || "ally".equals(normalized)) {
			return config.getFriendlyTeamColor();
		}
		if ("enemy".equals(normalized) || "hostile".equals(normalized)) {
			return config.getEnemyTeamColor();
		}
		if ("neutral".equals(normalized)) {
			return config.getNeutralTeamColor();
		}
		return fallbackColor;
	}

	private void registerWaypointSyncListener() {
		networkManager.addWaypointUpdateListener(new PlayerESPNetworkManager.WaypointUpdateListener() {
			@Override
			public void onWaypointsReceived(Map<String, SharedWaypointInfo> waypoints) {
				if (waypoints == null || waypoints.isEmpty()) {
					return;
				}
				sharedWaypoints.putAll(waypoints);
			}

			@Override
			public void onWaypointsDeleted(List<String> waypointIds) {
				if (waypointIds == null || waypointIds.isEmpty()) {
					return;
				}
				for (String waypointId : waypointIds) {
					sharedWaypoints.remove(waypointId);
					trackedEntityWaypointLastPositions.remove(waypointId);
				}
				XaeroWaypointShareBridge.deleteSharedWaypoints(waypointIds);
			}
		});
	}

	private void handleMiddleMouseDoubleClickMarking(MinecraftClient client) {
		if (config == null) {
			middlePressedLastTick = false;
			return;
		}

		boolean enableDoubleClickMark = config.isEnableMiddleDoubleClickMark();
		boolean enableClickCancel = config.isEnableMiddleClickCancelWaypoint();
		if (!enableDoubleClickMark && !enableClickCancel) {
			middlePressedLastTick = false;
			return;
		}

		if (!canCreateMark(client)) {
			middlePressedLastTick = false;
			return;
		}

		long windowHandle = client.getWindow().getHandle();
		boolean middlePressed = GLFW.glfwGetMouseButton(windowHandle, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;

		if (middlePressed && !middlePressedLastTick) {
			if (enableClickCancel && tryCancelTargetedWaypoint(client)) {
				lastMiddleClickTs = 0L;
				middlePressedLastTick = middlePressed;
				return;
			}
			if (!enableDoubleClickMark) {
				middlePressedLastTick = middlePressed;
				return;
			}

			long now = System.currentTimeMillis();
			if (now - lastMiddleClickTs <= MARK_DOUBLE_CLICK_MS) {
				lastMiddleClickTs = 0L;
				createAndSyncQuickMark(client);
			} else {
				lastMiddleClickTs = now;
			}
		}

		middlePressedLastTick = middlePressed;
	}

	private void handleAutoCancelWaypointOnEntityDeath(MinecraftClient client) {
		if (config == null || !config.isAutoCancelWaypointOnEntityDeath()) {
			return;
		}
		if (client == null || client.player == null || client.world == null || sharedWaypoints.isEmpty()) {
			return;
		}

		UUID localPlayerId = client.player.getUuid();
		String currentDimension = client.world.getRegistryKey().getValue().toString();
		Map<String, Entity> localEntitiesById = new HashMap<>();
		for (Entity entity : client.world.getEntities()) {
			if (entity == null) {
				continue;
			}
			localEntitiesById.put(entity.getUuidAsString(), entity);
		}

		Map<String, LivingEntity> confirmedDeadEntities = new HashMap<>();
		for (Map.Entry<String, Entity> entry : localEntitiesById.entrySet()) {
			Entity entity = entry.getValue();
			if (!(entity instanceof LivingEntity livingEntity)) {
				continue;
			}
			if (!isKillableMarkTarget(entity)) {
				continue;
			}
			if (!isEntityDeathConfirmed(livingEntity)) {
				continue;
			}
			confirmedDeadEntities.put(entry.getKey(), livingEntity);
		}
		if (confirmedDeadEntities.isEmpty()) {
			return;
		}

		List<String> toDelete = new java.util.ArrayList<>();
		List<String> cancelledTargetEntityIds = new java.util.ArrayList<>();
		for (Map.Entry<String, SharedWaypointInfo> entry : sharedWaypoints.entrySet()) {
			String waypointId = entry.getKey();
			SharedWaypointInfo waypoint = entry.getValue();
			if (waypoint == null) {
				continue;
			}
			if (!"entity".equalsIgnoreCase(waypoint.targetType())) {
				continue;
			}
			if (waypoint.dimension() != null && !waypoint.dimension().isBlank() && !waypoint.dimension().equals(currentDimension)) {
				continue;
			}
			String targetEntityId = waypoint.targetEntityId();
			if (targetEntityId == null || targetEntityId.isBlank()) {
				continue;
			}
			if (!confirmedDeadEntities.containsKey(targetEntityId)) {
				continue;
			}

			toDelete.add(waypointId);
			cancelledTargetEntityIds.add(targetEntityId);
		}

		if (toDelete.isEmpty()) {
			return;
		}

		for (String waypointId : toDelete) {
			SharedWaypointInfo removed = sharedWaypoints.remove(waypointId);
			trackedEntityWaypointLastPositions.remove(waypointId);
			XaeroWaypointShareBridge.deleteSharedWaypoint(waypointId);
			if (removed != null && client.player != null) {
				String removedName = removed.name() == null || removed.name().isBlank() ? waypointId : removed.name();
				client.player.sendMessage(Text.literal("§7[TV] 目标已确认死亡，自动取消报点: " + removedName), true);
			}
		}

		if (networkManager != null && networkManager.isConnected()) {
			networkManager.sendWaypointEntityDeathCancel(localPlayerId, cancelledTargetEntityIds);
		}
	}

	private boolean isKillableMarkTarget(Entity entity) {
		return entity instanceof LivingEntity;
	}

	private boolean isEntityDeathConfirmed(LivingEntity livingEntity) {
		return livingEntity.getHealth() <= 0.0F;
	}

	private boolean tryCancelTargetedWaypoint(MinecraftClient client) {
		if (client == null || client.player == null || client.world == null || sharedWaypoints.isEmpty()) {
			return false;
		}

		UUID localPlayerId = client.player.getUuid();
		String currentDimension = client.world.getRegistryKey().getValue().toString();
		Vec3d eyePos = client.player.getCameraPosVec(1.0F);
		Vec3d lookVec = client.player.getRotationVec(1.0F).normalize();
		double maxDistance = Math.max(config.getRenderDistance(), MARK_RAYCAST_DISTANCE);

		String selectedWaypointId = null;
		double selectedScore = Double.MAX_VALUE;

		for (Map.Entry<String, SharedWaypointInfo> entry : sharedWaypoints.entrySet()) {
			SharedWaypointInfo waypoint = entry.getValue();
			if (waypoint == null) {
				continue;
			}
			if (waypoint.ownerId() == null || !localPlayerId.equals(waypoint.ownerId())) {
				continue;
			}
			if (waypoint.dimension() != null && !waypoint.dimension().isBlank() && !waypoint.dimension().equals(currentDimension)) {
				continue;
			}

			Vec3d waypointPos = resolveWaypointWorldPosition(client, waypoint, currentDimension);
			if (waypointPos == null) {
				continue;
			}

			Vec3d toWaypoint = waypointPos.subtract(eyePos);
			double alongRay = toWaypoint.dotProduct(lookVec);
			if (alongRay <= 0.0D || alongRay > maxDistance) {
				continue;
			}

			Vec3d closestPoint = eyePos.add(lookVec.multiply(alongRay));
			double lateralDistance = waypointPos.distanceTo(closestPoint);
			double allowedRadius = Math.min(
				MARK_CANCEL_MAX_RADIUS,
				MARK_CANCEL_BASE_RADIUS + alongRay * MARK_CANCEL_RADIUS_PER_BLOCK
			);
			if (lateralDistance > allowedRadius) {
				continue;
			}

			double score = lateralDistance + alongRay * 0.0025D;
			if (score < selectedScore) {
				selectedScore = score;
				selectedWaypointId = entry.getKey();
			}
		}

		if (selectedWaypointId == null) {
			return false;
		}

		SharedWaypointInfo removed = sharedWaypoints.remove(selectedWaypointId);
		trackedEntityWaypointLastPositions.remove(selectedWaypointId);
		XaeroWaypointShareBridge.deleteSharedWaypoint(selectedWaypointId);
		networkManager.sendWaypointsDelete(localPlayerId, List.of(selectedWaypointId));

		if (removed != null) {
			String removedName = removed.name() == null || removed.name().isBlank() ? selectedWaypointId : removed.name();
			client.player.sendMessage(Text.literal("§e[TV] 已取消报点: " + removedName), true);
		}
		return true;
	}

	private boolean canCreateMark(MinecraftClient client) {
		return espEnabled
			&& client != null
			&& client.player != null
			&& client.world != null
			&& client.currentScreen == null
			&& networkManager != null
			&& networkManager.isConnected();
	}

	private void createAndSyncQuickMark(MinecraftClient client) {
		if (client.player == null || client.world == null) {
			return;
		}

		MarkTarget target = resolveMarkTarget(client);
		if (target == null) {
			client.player.sendMessage(Text.literal("§c[TV] 报点失败：未命中方块或实体"), true);
			return;
		}

		Vec3d worldPos = target.position();
		int markX = (int) Math.floor(worldPos.x);
		int markY = (int) Math.floor(worldPos.y);
		int markZ = (int) Math.floor(worldPos.z);

		UUID ownerId = client.player.getUuid();
		String ownerName = client.player.getName().getString();
		String dimension = client.world.getRegistryKey().getValue().toString();
		long createdAt = System.currentTimeMillis();
		String idSource = ownerId + "|" + createdAt + "|" + dimension + "|" + markX + "|" + markY + "|" + markZ;
		String waypointId = UUID.nameUUIDFromBytes(idSource.getBytes(StandardCharsets.UTF_8)).toString();

		int maxQuickMarkCount = config.getMaxQuickMarkCount();
		List<String> overflowQuickWaypointIds = collectOverflowQuickWaypointIdsByOwner(ownerId, waypointId, maxQuickMarkCount);
		if (!overflowQuickWaypointIds.isEmpty()) {
			for (String oldId : overflowQuickWaypointIds) {
				sharedWaypoints.remove(oldId);
			}
			networkManager.sendWaypointsDelete(ownerId, overflowQuickWaypointIds);
		}

		String targetType = target.targetEntity() == null ? "block" : "entity";
		String targetEntityId = target.targetEntity() == null ? null : target.targetEntity().getUuidAsString();
		String targetEntityType = target.targetEntity() == null
				? null
				: target.targetEntity().getType().toString();
		String targetEntityName = target.targetEntity() == null
				? null
				: target.targetEntity().getDisplayName().getString();

		String markName;
		if (target.targetEntity() != null) {
			String displayName = targetEntityName == null || targetEntityName.isBlank() ? "Entity" : targetEntityName;
			markName = "报点[实体] " + displayName;
		} else {
			markName = "报点";
		}

		SharedWaypointInfo waypoint = new SharedWaypointInfo(
			waypointId,
			ownerId,
			ownerName,
			markName,
			"!",
			markX,
			markY,
			markZ,
			dimension,
			MARKER_COLOR_RGB,
			createdAt,
			targetType,
			targetEntityId,
			targetEntityType,
			targetEntityName,
			"quick",
			null,
			null
		);
		sharedWaypoints.put(waypointId, waypoint);

		Map<String, Object> payload = new HashMap<>();
		payload.put("x", markX);
		payload.put("y", markY);
		payload.put("z", markZ);
		payload.put("dimension", dimension);
		payload.put("name", waypoint.name());
		payload.put("symbol", waypoint.symbol());
		payload.put("color", waypoint.color());
		payload.put("ownerId", ownerId.toString());
		payload.put("ownerName", ownerName);
		payload.put("createdAt", createdAt);
		payload.put("ttlSeconds", config.getWaypointTimeoutSeconds());
		payload.put("waypointKind", "quick");
		payload.put("maxQuickMarks", maxQuickMarkCount);
		payload.put("targetType", targetType);
		payload.put("targetEntityId", targetEntityId);
		payload.put("targetEntityType", targetEntityType);
		payload.put("targetEntityName", targetEntityName);

		Map<String, Map<String, Object>> toUpload = new HashMap<>();
		toUpload.put(waypointId, payload);
		networkManager.sendWaypointsUpdate(ownerId, toUpload);

		if (target.targetEntity() != null) {
			String displayName = targetEntityName == null || targetEntityName.isBlank() ? "实体" : targetEntityName;
			client.player.sendMessage(Text.literal("§6[TV] 已报点实体: " + displayName + " @ " + markX + " " + markY + " " + markZ), true);
		} else {
			client.player.sendMessage(Text.literal("§6[TV] 已报点方块: " + markX + " " + markY + " " + markZ), true);
		}
	}

	private List<String> collectOverflowQuickWaypointIdsByOwner(UUID ownerId, String exceptWaypointId, int maxKeepCount) {
		List<Map.Entry<String, SharedWaypointInfo>> quickEntries = new java.util.ArrayList<>();
		for (Map.Entry<String, SharedWaypointInfo> entry : sharedWaypoints.entrySet()) {
			SharedWaypointInfo waypoint = entry.getValue();
			if (waypoint == null) {
				continue;
			}
			if (exceptWaypointId != null && exceptWaypointId.equals(entry.getKey())) {
				continue;
			}
			if (!ownerId.equals(waypoint.ownerId())) {
				continue;
			}
			if (!"quick".equalsIgnoreCase(waypoint.waypointKind())) {
				continue;
			}
			quickEntries.add(entry);
		}

		int normalizedMax = Math.max(1, maxKeepCount);
		int removeCount = quickEntries.size() - normalizedMax + 1;
		if (removeCount <= 0) {
			return List.of();
		}

		quickEntries.sort(Comparator.comparingLong(left -> left.getValue().createdAt()));
		List<String> overflowIds = new java.util.ArrayList<>();
		for (int index = 0; index < removeCount && index < quickEntries.size(); index++) {
			overflowIds.add(quickEntries.get(index).getKey());
		}
		return overflowIds;
	}

	private MarkTarget resolveMarkTarget(MinecraftClient client) {
		if (client.player == null || client.world == null) {
			return null;
		}

		Vec3d eyePos = client.player.getCameraPosVec(1.0F);
		Vec3d lookVec = client.player.getRotationVec(1.0F).normalize();
		double maxDistance = Math.max(config.getRenderDistance(), MARK_RAYCAST_DISTANCE);
		Vec3d rayEnd = eyePos.add(lookVec.multiply(maxDistance));

		BlockHitResult blockHit = client.world.raycast(new RaycastContext(
			eyePos,
			rayEnd,
			RaycastContext.ShapeType.OUTLINE,
			RaycastContext.FluidHandling.NONE,
			client.player
		));

		double blockDistSq = Double.MAX_VALUE;
		Vec3d blockMarkPos = null;
		if (blockHit != null && blockHit.getType() == HitResult.Type.BLOCK) {
			blockDistSq = eyePos.squaredDistanceTo(blockHit.getPos());
			blockMarkPos = new Vec3d(
				blockHit.getBlockPos().getX() + 0.5D,
				blockHit.getBlockPos().getY() + 1.0D,
				blockHit.getBlockPos().getZ() + 0.5D
			);
		}

		Box searchBox = client.player.getBoundingBox().stretch(lookVec.multiply(maxDistance)).expand(1.0D);
		EntityHitResult entityHit = ProjectileUtil.raycast(
			client.player,
			eyePos,
			rayEnd,
			searchBox,
			entity -> entity != null && entity.isAlive() && !entity.isSpectator() && entity.canHit(),
			maxDistance * maxDistance
		);

		double entityDistSq = Double.MAX_VALUE;
		Entity entityTarget = null;
		Vec3d entityMarkPos = null;
		if (entityHit != null && entityHit.getEntity() != null) {
			entityTarget = entityHit.getEntity();
			entityMarkPos = entityTarget.getPos();
			entityDistSq = eyePos.squaredDistanceTo(entityHit.getPos());
		}

		if (entityMarkPos == null && blockMarkPos == null) {
			return null;
		}
		if (entityMarkPos != null && entityDistSq <= blockDistSq) {
			return new MarkTarget(entityMarkPos, entityTarget);
		}
		return new MarkTarget(blockMarkPos, null);
	}

	private void renderSharedWaypointMarkers(WorldRenderContext context, Vec3d cameraPos, boolean depthTestEnabled) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.world == null) {
			return;
		}
		if (!config.isShowSharedWaypoints() || sharedWaypoints.isEmpty()) {
			return;
		}

		String currentDimension = client.world.getRegistryKey().getValue().toString();
		double maxDistance = Math.max(config.getRenderDistance(), 16.0);

		for (SharedWaypointInfo waypoint : sharedWaypoints.values()) {
			if (waypoint == null) {
				continue;
			}
			if (waypoint.dimension() != null && !waypoint.dimension().isBlank() && !waypoint.dimension().equals(currentDimension)) {
				continue;
			}

			Vec3d worldPos = resolveWaypointWorldPosition(client, waypoint, currentDimension);
			if (worldPos == null) {
				continue;
			}
			boolean isTmWaypoint = isTampermonkeyWaypoint(waypoint);
			if (!isTmWaypoint && client.player.getPos().distanceTo(worldPos) > maxDistance) {
				continue;
			}

			int color = withAlpha(waypoint.color(), 0xCC);
			if (isTmWaypoint) {
				renderTampermonkeyWaypointStyle(context, waypoint, worldPos, cameraPos, color, depthTestEnabled);
				continue;
			}

			Vec3d relativePos = worldPos.subtract(cameraPos);
			renderWaypointMarkerStyle(context, relativePos, color, depthTestEnabled);
		}
	}

	private boolean isTampermonkeyWaypoint(SharedWaypointInfo waypoint) {
		if (waypoint == null) {
			return false;
		}

		String sourceType = waypoint.sourceType();
		if (sourceType != null && sourceType.equalsIgnoreCase("admin_tactical")) {
			return true;
		}

		String waypointKind = waypoint.waypointKind();
		return waypointKind != null && waypointKind.equalsIgnoreCase("admin_tactical");
	}

	private void renderTampermonkeyWaypointStyle(
		WorldRenderContext context,
		SharedWaypointInfo waypoint,
		Vec3d resolvedWorldPos,
		Vec3d cameraPos,
		int color,
		boolean depthTestEnabled
	) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.world == null) {
			return;
		}

		double renderX = resolvedWorldPos.x;
		double renderZ = resolvedWorldPos.z;
		double baseY = client.world.getBottomY();
		double beamHeight = config.getTampermonkeyBeamHeight();

		Vec3d beamBaseRelative = new Vec3d(renderX - cameraPos.x, baseY - cameraPos.y, renderZ - cameraPos.z);
		Vec3d beamCenter = beamBaseRelative.add(0.0D, 0.08D, 0.0D);
		UnifiedRenderModule.drawVerticalBeam(
			context.matrixStack(),
			beamCenter,
			beamHeight,
			config.getTampermonkeyBeamWidth(),
			withAlpha(color, 0x55),
			depthTestEnabled
		);

		Vec3d planeCenter = new Vec3d(renderX - cameraPos.x, baseY - cameraPos.y + 0.03D, renderZ - cameraPos.z);
		UnifiedRenderModule.drawHorizontalPlane(
			context.matrixStack(),
			planeCenter,
			1.8D,
			withAlpha(color, 0x4C),
			depthTestEnabled
		);

		renderCircle(
			context,
			planeCenter,
			1.15D,
			withAlpha(color, 0xA6),
			24,
			depthTestEnabled
		);

		Vec3d topCenter = beamCenter.add(0.0D, beamHeight, 0.0D);
		renderCircle(
			context,
			topCenter,
			0.48D,
			withAlpha(color, 0x9A),
			18,
			depthTestEnabled
		);
	}

	private Vec3d resolveWaypointWorldPosition(MinecraftClient client, SharedWaypointInfo waypoint, String currentDimension) {
		if (waypoint == null) {
			return null;
		}

		String targetType = waypoint.targetType();
		String targetEntityId = waypoint.targetEntityId();
		if (!"entity".equalsIgnoreCase(targetType) || targetEntityId == null || targetEntityId.isBlank()) {
			return new Vec3d(waypoint.x() + 0.5D, waypoint.y(), waypoint.z() + 0.5D);
		}

		Vec3d localEntityPos = resolveLocalEntityPosition(client, targetEntityId, currentDimension);
		if (localEntityPos != null) {
			trackedEntityWaypointLastPositions.put(waypoint.waypointId(), localEntityPos);
			return localEntityPos;
		}

		if (isPlayerTarget(waypoint)) {
			Vec3d localPlayerPos = resolveLocalPlayerPositionFallback(client, targetEntityId, waypoint.targetEntityName(), currentDimension);
			if (localPlayerPos != null) {
				trackedEntityWaypointLastPositions.put(waypoint.waypointId(), localPlayerPos);
				return localPlayerPos;
			}
		}

		Vec3d remoteEntityPos = networkManager == null ? null : networkManager.getRemoteEntityPosition(targetEntityId, currentDimension);
		if (remoteEntityPos != null) {
			trackedEntityWaypointLastPositions.put(waypoint.waypointId(), remoteEntityPos);
			return remoteEntityPos;
		}

		if (isPlayerTarget(waypoint) && networkManager != null) {
			Vec3d remotePlayerPos = networkManager.getRemotePlayerPosition(targetEntityId, waypoint.targetEntityName(), currentDimension);
			if (remotePlayerPos != null) {
				trackedEntityWaypointLastPositions.put(waypoint.waypointId(), remotePlayerPos);
				return remotePlayerPos;
			}
		}

		Vec3d lastKnown = trackedEntityWaypointLastPositions.get(waypoint.waypointId());
		if (lastKnown != null) {
			return lastKnown;
		}

		Vec3d initial = new Vec3d(waypoint.x() + 0.5D, waypoint.y(), waypoint.z() + 0.5D);
		trackedEntityWaypointLastPositions.put(waypoint.waypointId(), initial);
		return initial;
	}

	private Vec3d resolveLocalEntityPosition(MinecraftClient client, String entityUuid, String currentDimension) {
		if (client == null || client.world == null || entityUuid == null || entityUuid.isBlank()) {
			return null;
		}

		String worldDimension = client.world.getRegistryKey().getValue().toString();
		if (currentDimension != null && !currentDimension.isBlank() && !currentDimension.equals(worldDimension)) {
			return null;
		}

		try {
			UUID uuid = UUID.fromString(entityUuid);
			Entity cached = entityUuidCache.get(uuid);
			if (cached != null && cached.isAlive()) {
				return cached.getPos();
			}
		} catch (IllegalArgumentException ignored) {
		}

		return null;
	}
	
	private void updateEntityCache(MinecraftClient client) {
		if (client == null || client.world == null) {
			entityUuidCache.clear();
			lastCachedDimension = null;
			return;
		}
		
		String currentDimension = client.world.getRegistryKey().getValue().toString();
		if (!currentDimension.equals(lastCachedDimension)) {
			entityUuidCache.clear();
			lastCachedDimension = currentDimension;
		}
		
		entityUuidCache.entrySet().removeIf(entry -> {
			Entity e = entry.getValue();
			return e == null || !e.isAlive();
		});
		
		for (Entity entity : client.world.getEntities()) {
			if (entity != null && entity.isAlive()) {
				entityUuidCache.put(entity.getUuid(), entity);
			}
		}
	}

	private Vec3d resolveLocalPlayerPositionFallback(MinecraftClient client, String targetEntityId, String targetEntityName, String currentDimension) {
		if (client == null || client.world == null) {
			return null;
		}

		String worldDimension = client.world.getRegistryKey().getValue().toString();
		if (currentDimension != null && !currentDimension.isBlank() && !currentDimension.equals(worldDimension)) {
			return null;
		}

		UUID expectedUuid = null;
		if (targetEntityId != null && !targetEntityId.isBlank()) {
			try {
				expectedUuid = UUID.fromString(targetEntityId);
			} catch (IllegalArgumentException ignored) {
			}
		}

		for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
			if (player == null) {
				continue;
			}
			if (expectedUuid != null && expectedUuid.equals(player.getUuid())) {
				return player.getPos();
			}
			if (targetEntityName != null && !targetEntityName.isBlank()) {
				String currentName = player.getName().getString();
				if (currentName != null && currentName.equalsIgnoreCase(targetEntityName)) {
					return player.getPos();
				}
			}
		}

		return null;
	}

	private boolean isPlayerTarget(SharedWaypointInfo waypoint) {
		if (waypoint == null) {
			return false;
		}
		String targetEntityType = waypoint.targetEntityType();
		return "minecraft:player".equalsIgnoreCase(targetEntityType);
	}

	private void renderWaypointMarkerStyle(WorldRenderContext context, Vec3d basePos, int color, boolean depthTestEnabled) {
		String style = config.getWaypointUiStyle();
		if (Config.WAYPOINT_UI_RING.equals(style)) {
			renderWaypointRingStyle(context, basePos, color, depthTestEnabled);
			return;
		}
		if (Config.WAYPOINT_UI_PIN.equals(style)) {
			renderWaypointPinStyle(context, basePos, color, depthTestEnabled);
			return;
		}
		renderWaypointBeaconStyle(context, basePos, color, depthTestEnabled);
	}

	private void renderWaypointBeaconStyle(WorldRenderContext context, Vec3d basePos, int color, boolean depthTestEnabled) {
		Vec3d center = basePos.add(0.0D, 0.1D, 0.0D);
		double beamHeight = config.getWaypointBeaconBeamHeight();
		double beamRadius = config.getWaypointBeaconBeamWidth();
		UnifiedRenderModule.drawVerticalBeam(context.matrixStack(), center, beamHeight, beamRadius, withAlpha(color, 0x66), depthTestEnabled);

		renderCircle(context, center.add(0.0D, 0.02D, 0.0D), 0.75D, withAlpha(color, 0xB0), 18, depthTestEnabled);
		renderCircle(context, center.add(0.0D, beamHeight, 0.0D), 0.42D, withAlpha(color, 0xA0), 14, depthTestEnabled);
	}

	private void renderWaypointRingStyle(WorldRenderContext context, Vec3d basePos, int color, boolean depthTestEnabled) {
		Vec3d center = basePos.add(0.0D, 0.05D, 0.0D);
		renderCircle(context, center, 0.95D, color, 24, depthTestEnabled);
		renderCircle(context, center.add(0.0D, 0.3D, 0.0D), 0.65D, withAlpha(color, 0x9A), 18, depthTestEnabled);

		for (int i = 0; i < 4; i++) {
			double angle = (Math.PI / 2.0D) * i;
			Vec3d start = center.add(Math.cos(angle) * 0.3D, 0.0D, Math.sin(angle) * 0.3D);
			Vec3d end = center.add(Math.cos(angle) * 1.2D, 0.0D, Math.sin(angle) * 1.2D);
			UnifiedRenderModule.drawLine(context.matrixStack(), start, end, withAlpha(color, 0x88), depthTestEnabled);
		}

		UnifiedRenderModule.drawLine(context.matrixStack(), center.add(0.0D, 0.1D, 0.0D), center.add(0.0D, 3.0D, 0.0D), withAlpha(color, 0xB5), depthTestEnabled);
	}

	private void renderWaypointPinStyle(WorldRenderContext context, Vec3d basePos, int color, boolean depthTestEnabled) {
		Vec3d center = basePos.add(0.0D, 0.1D, 0.0D);
		Vec3d head = basePos.add(0.0D, 2.8D, 0.0D);
		UnifiedRenderModule.drawLine(context.matrixStack(), center, head, color, depthTestEnabled);

		double size = 0.42D;
		Vec3d north = head.add(0.0D, 0.0D, -size);
		Vec3d south = head.add(0.0D, 0.0D, size);
		Vec3d east = head.add(size, 0.0D, 0.0D);
		Vec3d west = head.add(-size, 0.0D, 0.0D);
		UnifiedRenderModule.drawLine(context.matrixStack(), north, south, color, depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), east, west, color, depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), north, east, withAlpha(color, 0x9A), depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), east, south, withAlpha(color, 0x9A), depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), south, west, withAlpha(color, 0x9A), depthTestEnabled);
		UnifiedRenderModule.drawLine(context.matrixStack(), west, north, withAlpha(color, 0x9A), depthTestEnabled);

		renderCircle(context, center.add(0.0D, 0.02D, 0.0D), 0.35D, withAlpha(color, 0xB0), 12, depthTestEnabled);
	}

	private void renderCircle(WorldRenderContext context, Vec3d center, double radius, int color, int segments, boolean depthTestEnabled) {
		if (segments < 3) {
			return;
		}
		double step = (Math.PI * 2.0D) / segments;
		Vec3d prev = null;
		for (int i = 0; i <= segments; i++) {
			double angle = step * i;
			Vec3d current = new Vec3d(
				center.x + Math.cos(angle) * radius,
				center.y,
				center.z + Math.sin(angle) * radius
			);
			if (prev != null) {
				UnifiedRenderModule.drawLine(context.matrixStack(), prev, current, color, depthTestEnabled);
			}
			prev = current;
		}
	}

	private int withAlpha(int rgb, int alpha) {
		return ((alpha & 0xFF) << 24) | (rgb & 0x00FFFFFF);
	}

	private record MarkTarget(Vec3d position, Entity targetEntity) {
	}
	
	// 网络管理方法
	public static void reconnectToServer() {
		if (networkManager != null) {
			networkManager.disconnect();
			if (espEnabled) {
				networkManager.connect();
			}
		}
	}
	
	// Getter和Setter方法
	public static boolean isEspEnabled() {
		return espEnabled;
	}
	
	public static void setEspEnabled(boolean espEnabled) {
		StandaloneMultiPlayerESP.espEnabled = espEnabled;
	}
	
	
	public static Config getConfig() {
		return config;
	}
	
	public static Map<UUID, Vec3d> getPlayerPositions() {
		return playerPositions;
	}
	
	public static Map<UUID, Vec3d> getServerPlayerPositions() {
		return serverPlayerPositions;
	}
	
	public static PlayerESPNetworkManager getNetworkManager() {
		return networkManager;
	}
}